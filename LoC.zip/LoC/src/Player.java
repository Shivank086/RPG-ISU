import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class Player 
{
	private int x, y, xa, ya, w, l, coins, type, hp, maxHp, dmg, maxSpd, hpU, spdU, dmgU, spd, dmgA, spdA, counter, counterA, counterT, a;
	private boolean jumped;
	private Fireball f;
	private boolean menu, isAttacking = false, godMode, isAirAbb, isEarAbb = false;
	private static boolean hasF, hasW, hasE, hasA = false;
	private BufferedImage standFire, standWater, standEarth, standBase, standAir;
	private BufferedImage runB1, runB2, runB3, runB4, atkB1, atkB2, atkB3, atkB4, tranB;
	private BufferedImage runF1, runF2, runF3, runF4, atkF1, atkF2, atkF3, atkF4, tranF;
	private BufferedImage runW1, runW2, runW3, runW4, atkW1, atkW2, atkW3, atkW4, tranW;
	private BufferedImage runE1, runE2, runE3, runE4, atkE1, atkE2, atkE3, atkE4, tranE;
	private BufferedImage runA1, runA2, runA3, runA4, atkA1, atkA2, atkA3, atkA4, tranA;
	private BufferedImage run1, run2, run3, run4, atk1, atk2, atk3, atk4, tran;
	public Player(int x, int y, int w, int l)
	{
		this.x = x;
		this.xa = 0;
		this.y = y;
		this.ya = 0;
		this.w = w;
		this.l =  l;
		jumped = false;
		this.coins = 0;
		this.type = 0;
		this.hp = 10;
		this.maxHp = 10;
		dmg = 5;
		this.maxSpd = 8;
		this.spd = 8;
		a=x;
		try
		{
			standFire = ImageIO.read(new File("Battle_Stand_Fire.png"));
			standWater = ImageIO.read(new File("Battle_Stand_Water.png"));
			standAir = ImageIO.read(new File("Battle_Stand_Air.png"));
			standEarth = ImageIO.read(new File("Battle_Stand_Earth.png"));
			standBase = ImageIO.read(new File("Battle_Stand_Base.png"));

			runB1 = ImageIO.read(new File("run_base_1.png"));
			runB2 = ImageIO.read(new File("run_base_2.png"));
			runB3 = ImageIO.read(new File("run_base_3.png"));
			runB4 = ImageIO.read(new File("run_base_4.png"));
			atkB1 = ImageIO.read(new File("atk_base_1.png"));
			atkB2 = ImageIO.read(new File("atk_base_2.png"));
			atkB3 = ImageIO.read(new File("atk_base_3.png"));
			atkB4 = ImageIO.read(new File("atk_base_4.png"));
			tranB = ImageIO.read(new File("tran_base.png"));

			runF1 = ImageIO.read(new File("run_f_1.png"));
			runF2 = ImageIO.read(new File("run_f_2.png"));
			runF3 = ImageIO.read(new File("run_f_3.png"));
			runF4 = ImageIO.read(new File("run_f_4.png"));
			atkF1 = ImageIO.read(new File("atk_f_1.png"));
			atkF2 = ImageIO.read(new File("atk_f_2.png"));
			atkF3 = ImageIO.read(new File("atk_f_3.png"));
			atkF4 = ImageIO.read(new File("atk_f_4.png"));
			tranF = ImageIO.read(new File("tran_f.png"));
			
			runW1 = ImageIO.read(new File("run_w_1.png"));
			runW2 = ImageIO.read(new File("run_w_2.png"));
			runW3 = ImageIO.read(new File("run_w_3.png"));
			runW4 = ImageIO.read(new File("run_w_4.png"));
			atkW1 = ImageIO.read(new File("atk_w_1.png"));
			atkW2 = ImageIO.read(new File("atk_w_2.png"));
			atkW3 = ImageIO.read(new File("atk_w_3.png"));
			atkW4 = ImageIO.read(new File("atk_w_4.png"));
			tranW = ImageIO.read(new File("tran_w.png"));
			
			runE1 = ImageIO.read(new File("run_e_1.png"));
			runE2 = ImageIO.read(new File("run_e_2.png"));
			runE3 = ImageIO.read(new File("run_e_3.png"));
			runE4 = ImageIO.read(new File("run_e_4.png"));
			atkE1 = ImageIO.read(new File("atk_e_1.png"));
			atkE2 = ImageIO.read(new File("atk_e_2.png"));
			atkE3 = ImageIO.read(new File("atk_e_3.png"));
			atkE4 = ImageIO.read(new File("atk_e_4.png"));
			tranE = ImageIO.read(new File("tran_e.png"));
			
			runA1 = ImageIO.read(new File("run_a_1.png"));
			runA2 = ImageIO.read(new File("run_a_2.png"));
			runA3 = ImageIO.read(new File("run_a_3.png"));
			runA4 = ImageIO.read(new File("run_a_4.png"));
			atkA1 = ImageIO.read(new File("atk_a_1.png"));
			atkA2 = ImageIO.read(new File("atk_a_2.png"));
			atkA3 = ImageIO.read(new File("atk_a_3.png"));
			atkA4 = ImageIO.read(new File("atk_a_4.png"));
			tranA = ImageIO.read(new File("tran_a.png"));
		}catch(IOException e) {}
	}
	public void keyPressed(KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_RIGHT){
			setXa(getSpdA());
			setW(Math.abs(getW()));
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT){
			setXa(-getSpdA());
			setW(-Math.abs(getW()));
		}
		if (e.getKeyCode() == KeyEvent.VK_UP) if(!jumped) setYa(-18-getSpdA()/4);
		//if (e.getKeyCode() == KeyEvent.VK_R) {setX(500); setY(300);}
	}
	
	public void keyReleased(KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) setXa(0);
		if (e.getKeyCode() == KeyEvent.VK_LEFT) setXa(0);
	}
	
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public int getXa() {return xa;}
	public int getYa() {return ya;}
	public int getCoins() {return coins;}
	public int getHp() {return hp;}
	public int getMaxHp() {return maxHp;}
	public int getSpd() {return spd;}
	public int getMaxSpd() {return maxSpd;}
	public boolean getJumped() {return jumped;}
	public int getDmg() {return dmg;}
	public int getDmgA() {return dmgA;}
	public int getSpdA() {return spdA;}
	public int getType() {return type;}
	public int getHpU() {return hpU;}
	public int getSpdU() {return spdU;}
	public int getDmgU() {return dmgU;}
	public boolean getHasF() {return hasF;}
	public boolean getHasW() {return hasW;}
	public boolean getHasE() {return hasE;}
	public boolean getHasA() {return hasA;}
	public int getA() {return a;}
	public boolean getGodMode() {return godMode;}
	public boolean getIsAirAbb() {return isAirAbb;}
	public boolean getIsEarAbb() {return isEarAbb;}

	public void setIsAttacking(boolean set){isAttacking = set;}
	public void setCounterT(int T){counterT = T;}
	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}
	public void setW(int w) {this.w = w;}
	public void setL(int l) {this.l = l;}
	public void setXa(int xa) {this.xa = xa;}
	public void setYa(int ya) {this.ya = ya;}
	public void setHp(int hp) {this.hp = hp;}
	public void setMaxHp(int maxHp) {this.maxHp = maxHp;}
	public void setMaxSpd(int maxSpd) {this.maxSpd = maxSpd;}
	public void setCoins(int coins) {this.coins = coins;}
	public void setJumped(boolean jumped) {this.jumped = jumped;}
	public void setDmg(int dmg) {this.dmg = dmg;}
	public void setSpd(int spd) {this.spd = spd;}
	public void setDmgA(int dmgA) {this.dmgA = dmgA;}
	public void setSpdA(int spdA) {this.spdA = spdA;}
	public void setType(int type) {this.type=type;}
	public void setHpU(int hpU) {this.hpU = hpU;}
	public void setSpdU(int spdU) {this.spdU = spdU;}
	public void setDmgU(int dmgU) {this.dmgU = dmgU;}
	public void setHasF(boolean hasF) {this.hasF = hasF;}
	public void setHasW(boolean hasW) {this.hasW = hasW;}
	public void setHasE(boolean hasE) {this.hasE = hasE;}
	public void setHasA(boolean hasA) {this.hasA = hasA;}
	public void setA(int a) {this.a = a;}
	public void setGodMode(boolean gm) {godMode = gm;}
	public void setIsAirAbb(boolean air) {isAirAbb = air;}
	public void setIsEarAbb(boolean ear) {isEarAbb = ear;}
	
	public void paint(Graphics g)
	{
		if(getW()>0) setA(getX());
		else setA(getX()-getW());
		Graphics2D p = (Graphics2D) g;
		if(getType() == 1){
			run1 = runF1;
			run2 = runF2;
			run3 = runF3;
			run4 = runF4;
			atk1 = atkF1;
			atk2 = atkF2;
			atk3 = atkF3;
			atk4 = atkF4;
			tran = tranF;
			if(counterT>0){
				p.drawImage(tran, getA()-(getW()/Math.abs(getW()))*30, getY()-45, (int) (getW()*2.5), (int) (getL()*2.5), null);
				counterT--;
			}
			else if(isAttacking || counterA!=0) atk(p);
			else if(getXa()!=0) run(p);
			else p.drawImage(standFire.getSubimage(36, 19, 32, 46), getA(), getY(), getW(), getL(), null);
		}
		else if(getType() == 2) {
			run1 = runW1;
			run2 = runW2;
			run3 = runW3;
			run4 = runW4;
			atk1 = atkW1;
			atk2 = atkW2;
			atk3 = atkW3;
			atk4 = atkW4;
			tran = tranW;
			if(counterT>0){
				p.drawImage(tran, getA()-(getW()/Math.abs(getW()))*30, getY()-45, (int) (getW()*2.5), (int) (getL()*2.5), null);
				counterT--;
			}
			else if(isAttacking || counterA!=0) atk(p);
			else if(getXa()!=0) run(p);
			else p.drawImage(standWater.getSubimage(36, 19, 32, 46), getA(), getY(), getW(), getL(), null);
		}
		else if(getType() == 3){
			run1 = runE1;
			run2 = runE2;
			run3 = runE3;
			run4 = runE4;
			atk1 = atkE1;
			atk2 = atkE2;
			atk3 = atkE3;
			atk4 = atkE4;
			tran = tranE;
			if(counterT>0){
				p.drawImage(tran, getA()-(getW()/Math.abs(getW()))*30, getY()-45, (int) (getW()*2.5), (int) (getL()*2.5), null);
				counterT--;
			}
			else if(isAttacking || counterA!=0) atk(p);
			else if(getXa()!=0) run(p);
			else p.drawImage(standEarth.getSubimage(36, 19, 32, 46), getA(), getY(), getW(), getL(), null); 
		}
		else if(getType() == 4){
			run1 = runA1;
			run2 = runA2;
			run3 = runA3;
			run4 = runA4;
			atk1 = atkA1;
			atk2 = atkA2;
			atk3 = atkA3;
			atk4 = atkA4;
			tran = tranA;
			if(counterT>0){
				p.drawImage(tran, getA()-(getW()/Math.abs(getW()))*30, getY()-45, (int) (getW()*2.5), (int) (getL()*2.5), null);
				counterT--;
			}
			else if(isAttacking || counterA!=0) atk(p);
			else if(getXa()!=0) run(p);
			else p.drawImage(standAir.getSubimage(36, 19, 32, 46), getA(), getY(), getW(), getL(), null);
		}
		else{
			run1 = runB1;
			run2 = runB2;
			run3 = runB3;
			run4 = runB4;
			atk1 = atkB1;
			atk2 = atkB2;
			atk3 = atkB3;
			atk4 = atkB4;
			tran = tranB;
			if(isAttacking || counterA!=0) atk(p);
			else if(getXa()!=0) run1(p);
			else p.drawImage(standBase.getSubimage(36, 19, 32, 46), getA(), getY(), getW(), getL(), null);
		}
	}
	public void run1(Graphics2D p){
		counter++;
		if(counter>60) counter = 0;
		if(counter<15) p.drawImage(run1, getA(), getY()-25, (int) (getW()*1.7), (int) (getL()*1.7), null);
		else if(counter<30) p.drawImage(run2, getA(), getY()-25, (int) (getW()*1.7), (int) (getL()*1.7), null);
		else if(counter<45) p.drawImage(run3, getA(), getY()-25, (int) (getW()*1.7), (int) (getL()*1.7), null);
		else if(counter<60) p.drawImage(run4, getA(), getY()-25, (int) (getW()*1.7), (int) (getL()*1.7), null);
	}
	public void run(Graphics2D p){
		counter++;
		if(counter>60) counter = 0;
		if(counter<15) p.drawImage(run1, getA(), getY()-50, (int) (getW()*2.5), (int) (getL()*2.5), null);
		else if(counter<30) p.drawImage(run2, getA(), getY()-50, (int) (getW()*2.5), (int) (getL()*2.5), null);
		else if(counter<45) p.drawImage(run3, getA(), getY()-50, (int) (getW()*2.5), (int) (getL()*2.5), null);
		else if(counter<60) p.drawImage(run4, getA(), getY()-50, (int) (getW()*2.5), (int) (getL()*2.5), null);
	}
	public void atk(Graphics2D p){
		counterA++;
		if(counterA>32) counterA = 0;
		if(counterA<8) p.drawImage(atk1, getA(), getY()-55, (int) (getW()*2.5), (int) (getL()*2.5), null);
		else if(counterA<16) p.drawImage(atk2, getA(), getY()-55, (int) (getW()*2.5), (int) (getL()*2.5), null);
		else if(counterA<24) p.drawImage(atk3, getA(), getY()-55, (int) (getW()*2.5), (int) (getL()*2.5), null);
		else if(counterA<32) p.drawImage(atk4, getA(), getY()-55, (int) (getW()*2.5), (int) (getL()*2.5), null);
	}
	
	public void move(ArrayList<Wall> walls, int count)
	{
		if(getCoins()>9999) setCoins(9999);
		if(getDmg()>99) setDmg(99);
		if(getGodMode() && getHp()<10+5*getHpU()) setHp(10+5*getHpU());
		if(count>350){
			setIsAirAbb(false);
			setIsEarAbb(false);
		}
		if(getX()+getXa()<0||getX()+getXa()>1500-Math.abs(getW())) setXa(0); 
		if(getY()+getYa()<0||getY()+getYa()>720-getL()) setYa(0);
		if(!onWall(walls)) 
		{
			setYa(getYa()+1);
			setJumped(true);
		}
		else 
		{
			setJumped(false);
			if(getYa()>0)setYa(0);
		}
		if(underWall(walls))
		{
			if(getYa()<0) setYa(0);
		}
		if(onLeftWall(walls))
		{
			if(getXa()<0) setXa(0);
		}
		if(onRightWall(walls))
		{
			if(getXa()>0) setXa(0);
		}
		setX(getX()+getXa());
		setY(getY()+getYa());
		if(count==570){
			setDmgA(getDmg());
			setSpdA(getSpd());
		}
	}
	
	public boolean onWall(ArrayList<Wall> walls)
	{
		boolean xCol, yTopCol;
		for(Wall w: walls)
		{
			xCol = ((getX()<=w.getX()&&w.getX()<=getX()+Math.abs(getW()))||(w.getX()<=getX()&&getX()<=w.getX()+Math.abs(getW())));
			yTopCol = (getY()<w.getY()+getYa()+w.getW()&&getY()+getYa()+getL()>=w.getY());
			//System.out.println(xCol + " " + yCol);
			if(xCol&&yTopCol)
			{
				int overlap = (getY()+getL()-w.getY());
				if(overlap<30)setY(getY()-overlap);
				//System.out.println(overlap);
				return true;
			}
		}
		return false;
	}
	public boolean underWall (ArrayList<Wall> walls)
	{
		boolean xCol, yCol;
		for(Wall w: walls)
		{
			xCol = ((getX()<=w.getX()&&w.getX()<=getX()+Math.abs(getW()))||(w.getX()<=getX()&&getX()<=w.getX()+Math.abs(getW())));
			yCol = (getY()<=w.getY()+getL()&&getY()+getL()>=w.getY()+getL());
			if(xCol&&yCol)
			{
				int overlap = (w.getY()+w.getW()-getY());
				if(overlap<30)setY(getY()+overlap);
				return true;
			}
		}
		return false;
	}
	public boolean onLeftWall(ArrayList<Wall> walls) 
	{
	    boolean xCol, yCol;
	    for (Wall w : walls) 
	    {
	        xCol = (getX() +getXa() <= w.getX() + w.getW() && getX() >= w.getX());
	        yCol = (getY() < w.getY() + w.getL() && getY() + getL() > w.getY());
	        if (xCol && yCol) 
	        {
	            int overlap = getX() - (w.getX() + w.getW());
	            setX(w.getX() + w.getW() - getXa()/2-getXa()%2);
	            return true;
	        }
	    }
	    return false;
	}

	public boolean onRightWall(ArrayList<Wall> walls) 
	{
	    boolean xCol, yCol;
	    for (Wall w : walls) 
	    {
	        xCol = (getX() < w.getX() + w.getW() && getX() + Math.abs(getW())+ getXa() >= w.getX());
	        yCol = (getY() < w.getY() + w.getL() && getY() + getL() > w.getY());
	        if (xCol && yCol) 
	        {
	            int overlap = w.getX() + w.getW() - (getX() + Math.abs(getW()));
	            setX(w.getX() - Math.abs(getW()) - getXa()/2-getXa()%2);
	            return true;
	        }
	    }
	    return false;
	}
	
	public void abbWater(){
		setHp(getHp()+15);
		if(getHp()>10+getHpU()*5) setHp(10+getHpU()*5);
	}
	
	public void abbEarth(int count){
		setIsEarAbb(true);
	}
	
	public void abbAir(int count){
		setIsAirAbb(true);
	}
}