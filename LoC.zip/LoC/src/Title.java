import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;
import java.awt.*;

import javax.swing.JPanel;
import javax.swing.event.MouseInputAdapter;

import org.w3c.dom.events.MouseEvent;
public class Title extends MouseInputAdapter{
	private static Font mWar;
    private static BufferedImage tite;
    private static boolean title = true;
    private static Menu m;
    private static int cx = -1, cy = -1, mx, my;
	public Title(Menu m) {
        this.m = m;
		try
		{   tite = ImageIO.read(new File("Night_Castle_1.png"));
			mWar = Font.createFont(Font.TRUETYPE_FONT, new File("Mechanoid Warrior.ttf"));
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
			ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Mechanoid Warrior.ttf")));
			Thread.sleep(500);
		} catch (FontFormatException e) {e.printStackTrace();} catch (IOException e) {e.printStackTrace();} catch (InterruptedException e) {e.printStackTrace();}	
	}
    
	public int getCx(){return cx;}
	public int getCy(){return cy;}
	public int getMx(){return mx;}
	public int getMy(){return my;}
    public boolean getTitle(){return title;}
    
	public void setCx(int cx){this.cx = cx;}
	public void setCy(int cy){this.cy = cy;}
	public void setMx(int mx){this.mx = mx;}
	public void setMy(int my){this.my = my;}
	public void setTitle(boolean title){this.title = title;}


    public static void open(Graphics2D g){
        g.drawImage(tite, -247, 0, 1747, 998, null);
        g.setFont(mWar);
		g.setColor(Color.WHITE);
		g.setFont(g.getFont().deriveFont(Font.PLAIN, 60));
        g.drawString("The legend of", 900, 130);
        g.drawString("caelum", 1040, 190);
		g.setFont(g.getFont().deriveFont(Font.PLAIN, 50));
        if(mx>=1090 && mx<= 1230 && my>=235 && my<=270) g.setColor(new Color(255, 191, 0));
        g.drawString("play", 1090, 270);
        g.setColor(Color.BLACK);
        if(cx>=1090 && cx<= 1230 && cy>=235 && cy<=270){
            title = false;
        }
    }
}
