import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.*;
import java.awt.image.*;
public class Key 
{
	private int x, y, w, l;
	boolean s;
	private BufferedImage key;
	public Key(int x, int y, int w, int l, boolean s)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l;
		this.s = s;
		try 
		{
			key = ImageIO.read(new File("Key.png"));
		}catch(IOException e) {System.out.println("Sidney is stupid");}
	}
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public boolean getS() {return s;}
	
	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}
	public void setW(int w) {this.w = w;}
	public void setL(int l) {this.l = l;}
	public void setS(boolean s) {this.s = s;}
	
	public void paint(Graphics g)
	{
		Graphics2D k = (Graphics2D) g;
		if(getS())k.drawImage(key, getX(), getY(), getW(), getL(), null);
	}
	public boolean pCollision(Player pl)
	{
		return((pCollideY(pl))&&pCollideX(pl));
	}
	
	public boolean pCollideX(Player pl)
	{
		boolean fromLeft = (getX()+Math.abs(pl.getW())+50>=pl.getX()&&getX()<=50+pl.getX());
		boolean fromRight = (getX()<=50+pl.getX()+Math.abs(pl.getW())&&getX()+Math.abs(pl.getW())+50>=pl.getX()+Math.abs(pl.getW()));
		return((fromLeft||fromRight));
	}
	
	public boolean pCollideY(Player pl)
	{
		boolean fromUp = (getY()+getL()+2>=pl.getY()&&getY()<=2+pl.getY());
		boolean fromDown = (getY()<=50+pl.getY()+pl.getL()&&getY()+getL()+50>=pl.getY()+pl.getL());
		return (fromUp||fromDown);
	}
}
