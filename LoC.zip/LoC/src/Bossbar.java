import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;
public class Bossbar 
{
	private int x, y, w, l, hp, maxHp, type;
	private boolean s;
	public Bossbar(int x, int y, int w, int l, int hp, int type, boolean s)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l;
		this.hp = hp;
		maxHp = hp;
		this.type = type;
		this.s = s;
	}
	
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public int getHp() {return hp;}
	public int getMaxHp() {return maxHp;}
	public int getType() {return type;}
	public boolean getS() {return s;}

	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}
	public void setW(int w) {this.w = w;}
	public void setL(int l) {this.l = l;}
	public void setHp(int hp) {this.hp = hp;}
	public void setMaxHp(int MaxHp) {this.maxHp = MaxHp;}
	public void setType(int type) {this.type=type;}
	public void setS(boolean s) {this.s = s;}
	
	public void paint(Graphics g)
	{
		Graphics2D b = (Graphics2D) g;
		if(getType()==1) b.setColor(Color.RED);
		else if(getType()==2) b.setColor(Color.BLUE);
		else if(getType()==3) b.setColor(Color.YELLOW);
		else if(getType()==4) b.setColor(Color.GREEN);
		else b.setColor(Color.DARK_GRAY);
		b.fillRect(getX(), getY(), getW()*getHp()/getMaxHp(), getL());
		b.setStroke(new BasicStroke(10));
		b.setColor(Color.BLACK);
		b.drawRect(getX(), getY(), getW(), getL());
		b.setStroke(new BasicStroke(1));
	}
}
