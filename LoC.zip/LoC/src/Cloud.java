import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class Cloud 
{
	private int x, y, w, l, xa;
	private BufferedImage cloud = null;
	public Cloud(int x, int y, int w, int l, int xa)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l;
		this.xa = xa;
		try
		{
			cloud = ImageIO.read(new File("Cloud.png"));
		}catch(IOException e) {System.out.println("Failure");}
	}
	
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public int getXa() {return xa;}
	
	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}
	public void setW(int w) {this.w = w;}
	public void setL(int l) {this.l = l;}
	public void setXa(int xa) {this.xa = xa;}
	
	public void paint(Graphics g)
	{
		Graphics2D c = (Graphics2D) g;
		c.drawImage(cloud, getX(), getY(), getW(), getL(), null);
	}
	
	public void move()
	{
		if(getXa()>0)
		{
			setX(getX()+getXa());
			if(getX()>1500) setX(-getW());
		}
		else
		{
			setX(getX()+getXa());
			if(getX()+getW()<0) setX(1500);
		}
	}
}
