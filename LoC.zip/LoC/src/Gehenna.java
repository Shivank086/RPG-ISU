import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class Gehenna 
{
	private int hp;
	private int xa;
	private int ya;
	private int x;
	private int y;
	private int w;
	private int l;
	private int timer;
	private int dmg;
	private boolean visible;
	private boolean right;
	private boolean atk;
	private int type;
	private int AtkCooldown;
	private int spdMulti;
	private int dmgMulti;
	private BufferedImage GehennaWalkR;
	private BufferedImage GehennaWalkL;
	private BufferedImage GehennaAtkR;
	private BufferedImage GehennaAtkL;
	private int atkTmr;
	
	public int getHp() {return hp;}
	public int getXa() {return xa;}
	public int getYa() {return ya;}
	public int getTimer() {return timer;}
	public int getDmg() {return dmg;}
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public boolean getVisible() {return visible;}
	public boolean getRight() {return right;}
	public boolean getAtk() {return atk;}
	public int getType() {return type;}
	public int getAtkCooldown() {return AtkCooldown;}
	public int getSpdAdd() {return spdMulti;}
	public int getDmgAdd() {return dmgMulti;}
	public int getAtkTmr() {return atkTmr;}


	public void setHp(int hold) {hp = hold;}
	public void setX(int hold) {x = hold;}
	public void setY(int hold) {y = hold;}
	public void setW(int hold) {w = hold;}
	public void setL(int hold) {l = hold;}
	public void setXa(int hold) {xa = hold;}
	public void setYa(int hold) {ya = hold;}
	public void setTimer(int hold) {timer = hold;}
	public void setVisible(boolean hold) {visible = hold;}
	public void setRight(boolean hold) {right = hold;}
	public void setAtk(boolean hold) {atk = hold;}
	public void setType(int hold) {type = hold;}
	public void setAtkCooldown(int hold) {AtkCooldown = hold;}
	public void setSpdAdd(int hold) {spdMulti = hold;}
	public void setDmgAdd(int hold) {dmgMulti = hold;}
	public void setAtkTmr(int hold) {atkTmr = hold;}

	
	public Gehenna(int x, int y, int w, int l, int dmg, int hp, boolean visible)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l;
		this.dmg = dmg;
		this.hp = hp;
		this.visible = visible;
		right = true;
		xa = 0;
		ya = 0;
		timer = 0;
		type = 0;
		atk = false;
		try
		{
			GehennaWalkR = ImageIO.read(new File("FinalBossR0.png"));
		}catch(IOException e){System.out.println("failure");}
		try
		{
			GehennaWalkL = ImageIO.read(new File("FinalBossL0.png"));
		}catch(IOException e){System.out.println("failure");}try
		{
			GehennaAtkR = ImageIO.read(new File("FinalBossAtk0.png"));
		}catch(IOException e){System.out.println("failure");}
		try
		{
			GehennaAtkL = ImageIO.read(new File("FinalBossAtk1.png"));
		}catch(IOException e){System.out.println("failure");}
	}
	
	public void paint(Graphics g, Player pl)
	{
		Graphics2D ge = (Graphics2D) g;
		int plCenterX = pl.getX()+Math.abs(pl.getW())/2;
		int plCenterY = pl.getY() + pl.getL()/2;
		int centerX = getX()+getW()/2;
		int centerY = getY()+getW()/2;
		if(plCenterX<centerX) setRight(false);
		else setRight(true);
		if(getRight()&&getAtk()) ge.drawImage(GehennaAtkR, getX(), getY(), getW(), getL(), null);
		else if((!getRight())&&getAtk()) ge.drawImage(GehennaAtkL, getX(), getY(), getW(), getL(), null);
		else if(getRight()) ge.drawImage(GehennaWalkR, getX(), getY(), getW(), getL(), null);
		else ge.drawImage(GehennaWalkL, getX(), getY(), getW(), getL(), null);
	}
	
	public void move(Player pl, ArrayList<Fireball> f)
	{
		if(getType()==4) setSpdAdd(4);
		else setSpdAdd(0);
		setDmgAdd(10);
		int plCenterX = pl.getX()+pl.getW()/2;
		int plCenterY = pl.getY() + pl.getL()/2;
		int centerX = getX()+getW()/2;
		int centerY = getY()+getW()/2;
		if((plCenterX<centerX-10)||((!getRight()&&plCenterX<centerX))) setXa(-3-getSpdAdd());
		if(plCenterX>centerX+10||(((getRight())&&plCenterX>centerX))) setXa(3+getSpdAdd());
		if(getType()==1) setXa(getXa()*-1);
		if(getX()+getXa()>60&&getX()+getXa()+getW()<1440)setX(getX()+getXa());
		if(getAtkTmr()<=0)setAtk(false);
		else setAtkTmr(getAtkTmr()-1);
		int dx = Math.abs(centerX-plCenterX);
		int dy = Math.abs(centerY-plCenterY);
		if(getAtkCooldown()<0)
		{
			setAtk(true);
			setAtkTmr(10);
			if(getType()==1)
			{
				if(centerX<plCenterX) shootFireball(true, f);
				else shootFireball(false, f);
			}
			else if(getType()==2)
			{
				if(Math.hypot(dx, dy)<60) attack(pl); 
			}
			else if(getType()==3)
			{
				if(Math.hypot(dx, dy)<60) attack(pl); 
			}
			else
			{
				if(Math.hypot(dx, dy)<60) attack(pl); 
			}
			setAtkCooldown(150);
		}
		else
		{
			setAtkCooldown(getAtkCooldown()-1);
		}
		if(getTimer()<=0) 
		{
			setTimer(200);
			if(getType()==4) setType(1);
			else setType(getType()+1);
		}
		else
		{
			setTimer(getTimer()-1);
		}
	}
	
	public void attack(Player pl)
	{
		if(getType()==2)
		{
			if(pl.getType()==1) 
			{
				pl.setHp(pl.getHp()-getDmg()-10);
				setHp(getHp()+5+getDmg()/2);
				if(getHp()>1000) setHp(1000);
			}
			else
			{
				pl.setHp(pl.getHp()-getDmg());
				setHp(getHp()+getDmg()/2);
				if(getHp()>1000) setHp(1000);
			}
			pl.setYa(-20);
		}
		else if(getType()==3)
		{
			if(pl.getType()==1) pl.setHp(pl.getHp()-getDmg()-10-getDmgAdd());
			else pl.setHp(pl.getHp()-getDmg()-getDmgAdd());
			pl.setYa(-40);
		}
		else
		{
			if(pl.getType()==1) pl.setHp(pl.getHp()-getDmg()-10);
			else pl.setHp(pl.getHp()-getDmg());
			pl.setYa(-20);
		}
	}
	
	public void shootFireball(boolean r, ArrayList<Fireball> f)
	{
		if(r)f.add(new Fireball(getX()+getW()+10, getY(), 120, 60, 10, 1, 20));
		else f.add(new Fireball(getX()-130, getY(), 120, 60, 10, 3, 20));
	}
}
