import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class Petrissima 
{
	private int hp;
	private int xa;
	private int x;
	private int y;
	private int w;
	private int l;
	private int timer;
	private BufferedImage Petrissima0;
	private BufferedImage Petrissima1;
	private boolean visible;
	
	public int getHp() {return hp;}
	public int getXa() {return xa;}
	public int getTimer() {return timer;}
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public boolean getVisible() {return visible;}

	public void setHp(int hold) {hp = hold;}
	public void setX(int hold) {x = hold;}
	public void setY(int hold) {y = hold;}
	public void setW(int hold) {w = hold;}
	public void setL(int hold) {l = hold;}
	public void setXa(int hold) {xa = hold;}
	public void setTimer(int hold) {timer = hold;}
	public void setVisible(boolean hold) {visible = hold;}
	
	public Petrissima(int x, int y, int w, int l, int xa, int hp, boolean visible)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l;
		this.visible = visible;
		this.xa = xa;
		this.hp = hp;
		try
		{
			Petrissima0 = ImageIO.read(new File("EarthBoss0.png"));
		}catch(IOException e){System.out.println("failure");}
		try
		{
			Petrissima1 = ImageIO.read(new File("EarthBoss1.png"));
		}catch(IOException e){System.out.println("failure");}
	}
	
	public void paint(Graphics g)
	{
		Graphics2D p = (Graphics2D) g;
		if(getXa()<0)p.drawImage(Petrissima0, getX(), getY(), getW(), getL(), null);
		else p.drawImage(Petrissima1, getX(), getY(), getW(), getL(), null);
	}
	
	public void move()
	{
		int temp = getXa();
		if(getX()+temp<60||getX()+temp+getW()>1440)
		{
			if(getTimer()<1)
			{
				setXa(getXa()*-1);
				temp = getXa();
				setTimer(300);
			}
			else
			{
				temp = 0;
				setTimer(getTimer()-1);
			}
		}
		setX(getX()+temp);
	}
}
