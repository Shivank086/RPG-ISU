import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class Water 
{
	Color MURKY = new Color(64,122,130);
	boolean visible;
	public Water(boolean visible)
	{
		this.visible = visible;
	}
	
	public boolean getVisible() {return visible;}
	public void setVisible(boolean s) {visible = s;}
	
	public void paint(Graphics g)
	{
		Graphics2D w = (Graphics2D) g;
		w.setColor(MURKY);
		w.fillRect(60, 640, 1380, 20);
		w.setColor(Color.CYAN);
		w.drawLine(60, 640, 1440, 640);
		
	}
	
	public boolean pCollision(Player pl)
	{
		return(pl.getY()+pl.getL()>640&&getVisible());
	}
}
