import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class Ardinium 
{
	private int hp;
	private int xa;
	private int ya;
	private int x;
	private int y;
	private int w;
	private int l;
	private BufferedImage Ardinium0;
	private boolean visible;
	
	public int getHp() {return hp;}
	public int getXa() {return xa;}
	public int getYa() {return ya;}
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public boolean getVisible() {return visible;}

	public void setHp(int hold) {hp = hold;}
	public void setX(int hold) {x = hold;}
	public void setY(int hold) {y = hold;}
	public void setW(int hold) {w = hold;}
	public void setL(int hold) {l = hold;}
	public void setXa(int hold) {xa = hold;}
	public void setYa(int hold) {ya = hold;}
	public void setVisible(boolean hold) {visible = hold;}
	
	public Ardinium(int x, int y, int w, int l, int xa, int ya, int hp, boolean visible)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l;
		this.visible = visible;
		this.xa = xa;
		this.ya = ya;
		this.hp = hp;
		try
		{
			Ardinium0 = ImageIO.read(new File("FireBoss0.png"));
		}catch(IOException e){System.out.println("failure");}
	}
	
	public void paint(Graphics g)
	{
		Graphics2D a = (Graphics2D) g;
		a.drawImage(Ardinium0, getX(), getY(), getW(), getL(), null);
	}
	public void move() 
	{
		if(getX()+getXa()<60||getX()+getXa()+getW()>1440) setXa(getXa()*-1);
		if(getY()+getYa()<60||getY()+getYa()+getL()>640) setYa(getYa()*-1);
		setX(getX()+getXa());
		setY(getY()+getYa());
	}
	
}
