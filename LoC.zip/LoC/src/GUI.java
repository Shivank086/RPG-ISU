import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.image.*;
import java.awt.*;
public class GUI{
	private static Player pl;
    private static int count = 570;
	private static BufferedImage aIconFs, aIconWs, aIconEs, aIconAs, coin, heart, feather, sword = null;
	private static Font mWar;
	public GUI(Player pl) {
		this.pl = pl;
		try
		{
			aIconFs = ImageIO.read(new File("Fireballs.png"));
			aIconWs = ImageIO.read(new File("Heals.png"));
			aIconEs = ImageIO.read(new File("Rockwalls.png"));
			aIconAs = ImageIO.read(new File("Windgusts.png"));
			
			heart = ImageIO.read(new File("Heart.png"));
			feather = ImageIO.read(new File("Feather.png"));
			sword = ImageIO.read(new File("Sword.png"));
			
			coin = ImageIO.read(new File("Coin.png"));
			mWar = Font.createFont(Font.TRUETYPE_FONT, new File("Mechanoid Warrior.ttf"));
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
			ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Mechanoid Warrior.ttf")));
			Thread.sleep(500);
		} catch (FontFormatException e) {e.printStackTrace();} catch (IOException e) {e.printStackTrace();} catch (InterruptedException e) {e.printStackTrace();}	
	}
	public int getCount() {return count;}
    
	public void setCount(int count) {this.count = count;}

    public static void paint(Graphics2D g){
        if(count!=570) count++;
        g.setColor(Color.BLACK);
        g.setFont(mWar);
		g.setFont(g.getFont().deriveFont(Font.PLAIN, 35));
        
        g.drawImage(coin, 60, 5, 50, 50, null);
        g.drawString("x "+pl.getCoins(), 120, 42);
        g.drawImage(feather, 310, 5, 50, 50, null);
        g.drawString("x "+pl.getSpd(), 370, 42);
        g.drawImage(sword, 470, 5, 50, 50, null);
        g.drawString("x "+pl.getDmgA(), 530, 42);

        g.drawImage(heart, 640, 5, 50, 50, null);
        g.drawString("x", 700, 42);
        g.fillRect(740, 10, 80+40*pl.getHpU(), 40);
        g.setColor(Color.RED);
        g.fillRect(745, 15, pl.getHp()*8-10, 30); 
        







        if(pl.getType()==1 && pl.getHasF()){
            g.setColor(Color.BLACK);
            g.fillRect(1070, 10, 370, 40);
            g.drawImage(aIconFs, 1078, 15, 60, 30, null);
            g.setColor(Color.RED);
            g.fillRect(1150, 15, count/2, 30);
        }
        if(pl.getType()==2 && pl.getHasW()){
            g.setColor(Color.BLACK);
            g.fillRect(1070, 10, 370, 40);
            g.drawImage(aIconWs, 1078, 15, 60, 30, null);
            g.setColor(new Color(44, 148, 204));
            g.fillRect(1150, 15, count/2, 30);
        }
        if(pl.getType()==3 && pl.getHasE()){
            g.setColor(Color.BLACK);
            g.fillRect(1070, 10, 370, 40);
            g.drawImage(aIconEs, 1078, 15, 60, 30, null);
            g.setColor(new Color(154, 114, 84));
            g.fillRect(1150, 15, count/2, 30);
        }
        if(pl.getType()==4 && pl.getHasA()){
            g.setColor(Color.BLACK);
            g.fillRect(1070, 10, 370, 40);
            g.drawImage(aIconAs, 1078, 15, 60, 30, null);
            g.setColor(new Color(184, 244, 188));
            g.fillRect(1150, 15, count/2, 30);
        }
        
    }
}
