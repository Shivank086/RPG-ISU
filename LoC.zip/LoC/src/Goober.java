import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class Goober
{
	int type, x, y, spd, dmg, hp, dim, cooldown, ya;
	double size;
	private BufferedImage fire = null;
	private BufferedImage water = null;
	private BufferedImage earth = null;
	private BufferedImage air = null;
	public Goober(int type, double size, int x, int y)
	{
		this.type = type;
		this.size = size;
		this.x = x;
		this.y = y;
		spd = 4;
		dmg = (int)(5*this.size);
		hp = (int)(5*Math.pow(this.size, 4));
		dim = (int)(30*this.size);
		cooldown = 	100;
		ya = 0;
		try 
		{
			fire = ImageIO.read(new File("FireF0.png"));
		}catch(IOException e){}
		try 
		{
			water = ImageIO.read(new File("WaterF0.png"));
		}catch(IOException e){}
		try 
		{
			earth = ImageIO.read(new File("EarthF0.png"));
		}catch(IOException e){}
		try
		{
			air = ImageIO.read(new File("AirF0.png"));
		}catch(IOException e) {}
		//Implement different stats per goober
	}
	
	public int getHp() {return hp;}
	public int getDmg() {return dmg;}
	public double getSize() {return size;}
	public int getDim() {return dim;};
	public int getType() {return type;}
	public int getSpd() {return spd;}
	public int getX() {return x;}
	public int getY() {return y;}
	public int getYa() {return ya;}
	public int getCooldown() {return cooldown;}

	public void setHp(int hold) {hp = hold;}
	public void setDmg(int hold) {dmg = hold;}
	public void setSize(double hold) {size = hold; dim = (int)(30*hold);}
	public void setType(int hold) {type = hold;}
	public void setSpd(int hold) {spd = hold;}
	public void setX(int hold) {x = hold;}
	public void setY(int hold) {y = hold;}
	public void setYa(int hold) {ya = hold;}
	public void setCooldown(int hold) {cooldown = hold;}
	
	public void move(Player pl, ArrayList<Wall> walls) 
	{
		if(pCollision(pl)) {
			
			if(cooldown <= 0) {
				cooldown = 100;
				pl.setHp(pl.getHp()-getDmg());
				setSpd(getSpd()*-1);
			}
		}
		if(!onWall(walls)) 
		{
			setYa(10);
		}
		else 
		{
			if(getYa()>0)setYa(0);
		}
		if(underWall(walls))
		{
			if(getYa()<0) setYa(0);
		}
		if(onLeftWall(walls))
		{
			if(getSpd()<0) setSpd(getSpd()*-1);
		}
		if(onRightWall(walls))
		{
			if(getSpd()>0) setSpd(getSpd()*-1);
		}
		setY(getYa()+getY());
		setX(getSpd()+getX());
	}
	
	public boolean pCollision(Player pl)
	{
		return((pCollideY(pl))&&pCollideX(pl));
	}
	
	public boolean pCollideX(Player pl)
	{
		boolean fromLeft = (getX()+getDim()+2>=pl.getX()&&getX()<=2+pl.getX());
		boolean fromRight = (getX()<=2+pl.getX()+Math.abs(pl.getW())&&getX()+getDim()+2>=pl.getX()+Math.abs(pl.getW()));
		return((fromLeft||fromRight));
	}
	
	public boolean pCollideY(Player pl)
	{
		boolean fromUp = (getY()+getDim()+2>=pl.getY()&&getY()<=2+pl.getY());
		boolean fromDown = (getY()<=2+pl.getY()+pl.getL()&&getY()+getDim()+2>=pl.getY()+pl.getL());
		return (fromUp||fromDown);
	}
	
	public void paint(Graphics g)
	{
		Graphics2D gb = (Graphics2D) g;
		if(getType()==2) gb.drawImage(water, getX(), getY(), getDim(), getDim(), null);
		else if(getType()==3) gb.drawImage(earth, getX(), getY(), getDim(), getDim(), null);
		else if(getType()==4) gb.drawImage(air, getX(), getY(), getDim(), getDim(), null);
		else gb.drawImage(fire, getX(), getY(), getDim(), getDim(), null);
	}
	public boolean onWall(ArrayList<Wall> walls)
	{
		boolean xCol, yTopCol;
		for(Wall w: walls)
		{
			xCol = ((getX()<=w.getX()&&w.getX()<=getX()+getDim())||(w.getX()<=getX()&&getX()<=w.getX()+getDim()));
			yTopCol = (getY()<w.getY()+w.getW()&&getY()+getDim()>=w.getY());
			//System.out.println(xCol + " " + yCol);
			if(xCol&&yTopCol)
			{
				int overlap = (getY()+getDim()-w.getY());
				setY(getY()-overlap);
				//System.out.println(overlap);
				return true;
			}
		}
		return false;
	}
	public boolean underWall (ArrayList<Wall> walls)
	{
		boolean xCol, yCol;
		for(Wall w: walls)
		{
			xCol = ((getX()<=w.getX()&&w.getX()<=getX()+getDim())||(w.getX()<=getX()&&getX()<=w.getX()+getDim()));
			yCol = (getY()<=w.getY()+getDim()&&getY()+getDim()>=w.getY()+getDim());
			if(xCol&&yCol)
			{
				int overlap = (w.getY()+w.getW()-getY());
				setY(getY()+overlap);
				return true;
			}
		}
		return false;
	}
	public boolean onLeftWall(ArrayList<Wall> walls) 
	{
	    boolean xCol, yCol;
	    for (Wall w : walls) 
	    {
	        xCol = (getX() - Math.abs(getSpd()) <= w.getX() + w.getW() && getX() >= w.getX());
	        yCol = (getY() < w.getY() + w.getL() && getY() + getDim() > w.getY());
	        if (xCol && yCol) 
	        {
	            int overlap = getX() - (w.getX() + w.getW());
	            setX(w.getX() + w.getW() + Math.abs(getSpd()));
	            return true;
	        }
	    }
	    return false;
	}

	public boolean onRightWall(ArrayList<Wall> walls) 
	{
	    boolean xCol, yCol;
	    for (Wall w : walls) 
	    {
	        xCol = (getX() < w.getX() + w.getW() && getX() + getDim() + Math.abs(getSpd()) >= w.getX());
	        yCol = (getY() < w.getY() + w.getL() && getY() + getDim() > w.getY());
	        if (xCol && yCol) 
	        {
	            int overlap = w.getX() + w.getW() - (getX() + getDim());
	            setX(w.getX() - getDim() - Math.abs(getSpd()));
	            return true;
	        }
	    }
	    return false;
	}
	
}
