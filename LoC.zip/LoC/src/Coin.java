import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.*;
import java.awt.image.*;
public class Coin 
{
	private BufferedImage coins;
	private int x, y, size, val;
	public Coin(int x, int y, int size, int val)
	{
		this.x = x;
		this.y = y;
		this.size = size;
		this.val = val;
		try 
		{
			coins = ImageIO.read(new File("Coin.png"));
		}catch(IOException e) {}
	}
	
	public int getX() {return x;}
	public int getY() {return y;}
	public int getSize() {return size;}
	public int getVal() {return val;}
	
	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}
	public void setSize(int size) {this.size = size;}
	public void setVal(int val) {this.val = val;}
	
	public void paint(Graphics g)
	{
		Graphics2D c = (Graphics2D) g;
		c.drawImage(coins, getX(), getY(), getSize(), getSize(), null);
	}
	
	public boolean pCollision(Player pl)
	{
		return((pCollideY(pl))&&pCollideX(pl));
	}
	
	public boolean pCollideX(Player pl)
	{
		boolean fromLeft = (getX()+getSize()+10>=pl.getX()&&getX()<=50+pl.getX());
		boolean fromRight = (getX()<=50+pl.getX()+Math.abs(pl.getW())&&getX()+getSize()+50>=pl.getX()+Math.abs(pl.getW()));
		return((fromLeft||fromRight));
	}
	
	public boolean pCollideY(Player pl)
	{
		boolean fromUp = (getY()+getSize()+10>=pl.getY()&&getY()<=50+pl.getY());
		boolean fromDown = (getY()<=50+pl.getY()+pl.getL()&&getY()+getSize()+50>=pl.getY()+pl.getL());
		return (fromUp||fromDown);
	}
}
