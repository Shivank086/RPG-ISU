import java.io.File;
import java.io.IOException;
import java.awt.*;
import javax.swing.event.MouseInputAdapter;

public class Victory extends MouseInputAdapter{
	private static Font mWar;
    private static boolean victory = false;
    private static int cx = -1, cy = -1, mx, my;
	public Victory() {
		try{   
			mWar = Font.createFont(Font.TRUETYPE_FONT, new File("Mechanoid Warrior.ttf"));
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
			ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Mechanoid Warrior.ttf")));
			Thread.sleep(500);
		} catch (FontFormatException e) {e.printStackTrace();} catch (IOException e) {e.printStackTrace();} catch (InterruptedException e) {e.printStackTrace();}	
	}
    
	public int getCx(){return cx;}
	public int getCy(){return cy;}
	public int getMx(){return mx;}
	public int getMy(){return my;}
    public boolean getVictory(){return victory;}
    
	public void setCx(int cx){this.cx = cx;}
	public void setCy(int cy){this.cy = cy;}
	public void setMx(int mx){this.mx = mx;}
	public void setMy(int my){this.my = my;}
	public void setVictory(boolean vict){victory = vict;}


    public static void open(Graphics2D g){
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, 1500, 720);
        g.setFont(mWar);
		g.setColor(Color.WHITE);
		g.setFont(g.getFont().deriveFont(Font.PLAIN, 80));
        g.drawString("The legend of Caelum", 210, 320);
		g.setFont(g.getFont().deriveFont(Font.PLAIN, 50));
        g.drawString("Thanks for playing", 440, 370);
        if(mx>=610 && mx<= 885 && my>=415 && my<=450) g.setColor(new Color(255, 191, 0));
        g.drawString("End Game", 610, 450);
        g.setColor(Color.BLACK);
        if(cx>=610 && cx<= 885 && cy>=415 && cy<=450) System.exit(0);
    }
}
