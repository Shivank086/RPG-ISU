import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.*;
public class Level 
{
	private int[][] map = new int[25][12];
	private ArrayList<Wall> walls = new ArrayList<Wall>();
	private int type, level;
	private Interface ui;
	private Door d;
	private boolean hasMoved = false, hasJumped = false, hasSwitched = false, flag = false, finishedTutorial = false, HasMenu = false; 
	private Font mWar = null;
	private BufferedImage cycle;
	public Level(int level)
	{
		this.level = level;
		type = (this.level-1)/5+1;
		if (level == 0) type = 0;
		for(int i = 0; i < 25; i++)
		{
			map[i][0] = 1;
			map[i][11] = 1;
		}
		for(int i = 0; i < 12; i++)
		{
			map[0][i] = 1;
			map[24][i] = 1;
		}
		if(this.level%5==1) map[2][9] = map[3][9] = map[4][9] = map[20][9] = map[21][9] = map[22][9] = map[6][7] = map[7][7] = map[8][7] = map[9][7] = map[10][7] = map[14][7] = map[15][7] = map[16][7] = map[17][7] = map[18][7] = 1; 
		if(this.level%5==2) map[11][9] = map[13][9] = map[9][9]= map[8][9]=  map[15][9] = map[16][9] = map[18][9] = map[19][9] = map[6][9] = map[5][9] = 1;  
		if(this.level%5==3) map[3][9] = map[4][9] = map[21][9] = map[20][9] = map[6][7] = map[7][7] = map[18][7] = map[17][7] = 1; 
		if(this.level%5==4) map[10][9] = map[9][9] = map[14][9] = map[15][9] = map[5][7] = map[6][7] = map[18][7] = map[19][7] = 1;
		if(this.level==10) map[2][9] = map[3][9]= map[22][9]= map[21][9] = map[5][7] = map[6][7] = map[19][7] = map[18][7] = map[8][5] = map[9][5] = map[16][5] = map[15][5] = 1;
		if(this.level==15) map[10][8] = map[9][8] = map[7][8] = map[6][8] = map[4][8] = map[3][8] = map[14][8] = map[15][8] = map[17][8] = map[18][8] = map[20][8] = map[21][8] =1;
		map[12][10] = 2;
		for(int i = 0; i < 25; i++)
		{
			for(int j = 0; j < 12; j++)
			{
				if(map[i][j]==1) walls.add(new Wall(i*60, j*60, 60, 60, type));
				if(map[i][j]==2) d = new Door(i*60, j*60, 60, 120);
			}
		}
		try
		{
			mWar = Font.createFont(Font.TRUETYPE_FONT, new File("Mechanoid Warrior.ttf"));
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
			ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Mechanoid Warrior.ttf")));
		}catch (IOException | FontFormatException e) {e.printStackTrace();} 
		try
		{
			cycle = ImageIO.read(new File("Cycle.png"));
		}catch(IOException e) {System.out.println("It is 3:34 AM, PLEASE WORK");}
	}
	public ArrayList<Wall> getWalls() {return walls;}
	public int[][] getMap(){return map;}
	public int getType(){return type;}
	public int getLevel(){return level;}
	public Door getDoor() {return d;}
	public boolean getHasMoved() {return hasMoved;}
	public boolean getHasJumped() {return hasJumped;}
	public boolean getHasSwitched() {return hasSwitched;}
	public boolean getFlag() {return flag;}
	public boolean getHasMenu() {return HasMenu;}
	public boolean getFinishedTutorial() {return finishedTutorial;}
	public void setWalls(ArrayList<Wall> w) {walls = w;}
	public void setLevel(int level) {this.level = level; type = (this.level-1)/5+1;}
	public void setMap(int[][] map) {for(int i = 0; i < 25; i++) {for(int j = 0; j < 12; j++) {this.map[i][j]=map[i][j];}}}
	public void setDoor(Door d) {d = this.d;}	
	public void setHasMoved(boolean s) {hasMoved = s;}
	public void setHasJumped(boolean s) {hasJumped = s;}
	public void setFlag(boolean s) {flag = s;}
	public void setHasSwitched(boolean s) {hasSwitched = s;}
	public void setHasMenu(boolean s) {HasMenu = s;}
	public void endTutorial() {finishedTutorial = true;}
	
	public void move(Interface ui)
	{
		if(!getHasMoved())
		{
			if(getFinishedTutorial())
			{
				setHasJumped(true);
				setHasMoved(true);
				setHasSwitched(true);
				setHasMenu(true);
				ui.k.setX(ui.pl.getX());
				ui.k.setY(630);
			}
			if(ui.pl.getX()>1300) 
			{
				setHasMoved(true);
				ui.pl.setX(75);
				addWall(4, 10);
				addWall(4, 9);
				addWall(7, 7);
				addWall(7, 8);
				addWall(7, 9);
				addWall(7, 10);
				addWall(8, 9);
				addWall(9, 9);
				addWall(10, 10);
				addWall(10, 9);
				addWall(10, 8);
				addWall(10, 7);
				addWall(10, 6);
				addWall(10, 5);
			}
		}
		else
		{
			if(!getHasJumped())
			{
				if(ui.pl.getX()>600)
				{
					setHasJumped(true);
				}
			}
			else
			{
				if(!getHasSwitched())
				{
					if(ui.pl.getType()!=0) 
					{
						setHasSwitched(true);
					}
				}
				else
				{
					if(!getHasMenu())
					{
						if(ui.menuHasOpened) 
						{
							setHasMenu(true);
							Goober g = new Goober(3, 1, 1000, 600);
							g.setSpd(0);
							g.setDmg(0);
							ui.goobs.add(g);
						}

					}
					else
					{
						if(ui.goobs.isEmpty())
						{
							if(!getFlag())
							{
								ui.k.setX(1000);
								ui.k.setY(630);
								ui.k.setS(true);
								setFlag(true);
							}
						}
					}
				}
			}
		}
	}
	
	public void paint(Graphics g, Interface ui)
	{
		Graphics2D l = (Graphics2D) g;
		getDoor().paint(l);
		for(Wall w: getWalls())
		{
			w.paint(l);
		}
		if(getLevel()==0)
		{
			g.setFont(mWar);
			l.setFont(g.getFont().deriveFont(Font.PLAIN, 20));
			l.setColor(Color.WHITE);
			if(!getHasMoved())l.drawString("Use left and right arrow keys to move around. Try to reach the other-side.", 65, 100);
			else if(!getHasJumped()) l.drawString("Press the up-arrow to jump. Try to reach the top of the platforms.", 65, 100);
			else if(!getHasSwitched()) 
			{
				l.drawString("Press [1], [2], [3], or [4] to switch elements. Later you will unlock powers, which require pressing [space].", 65, 100);
				l.drawString("Different elements are powerful against others, which is shown below.", 65, 140);
				//l.setColor(new Color(1, 1, 1));
				//l.fillRect(65, 150, 100, 100);
				l.drawImage(cycle, 100, 170, 300, 300, null);
				l.setColor(Color.WHITE);
			}
			else if(!getHasMenu()) 
			{
				l.drawString("Press [z] to open menu. From there, you can access various sub-menues.", 65, 100);
				l.drawString("Menu options include controls, upgrades, story, credits, cheats and quit buttons", 65, 140);
				l.drawString("Use your mouse to navigate and explore the menu!.", 65, 180);
			}
			else if(!ui.goobs.isEmpty()) l.drawString("Press [c] to attack. This is an Earth Goober, meaning fire is 1.5x effective.", 65, 100);
			else if(ui.k.getS()) l.drawString("Press [x] to pick-up items. Enemies drop keys which can open doors.", 65, 100);
			else l.drawString("Go through that door to start your journey. Good Luck!", 65, 100);
		}
	}
	
	public void addWall(int x, int y)
	{
		map[x][y] = 1;
		ArrayList<Wall> newWalls = getWalls();
		newWalls.add(new Wall(x*60, y*60, 60, 60, type));
		setWalls(newWalls);
	}
}
