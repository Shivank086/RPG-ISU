import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class Wall 
{
	private int x, y, w, l, type;
	private BufferedImage fireWall = null;
	private BufferedImage waterWall = null;
	private BufferedImage earthWall = null;
	private BufferedImage airWall = null;
	private BufferedImage finalWall = null;
	public Wall() {}
	public Wall(int x, int y, int w, int l, int type)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l;
		this.type = type;
		try
		{
			fireWall = ImageIO.read(new File("Fire_Wall.png"));
		}catch(IOException e) {}
		try
		{
			waterWall = ImageIO.read(new File("Water_Wall.png"));
		}catch(IOException e) {}
		try
		{
			earthWall = ImageIO.read(new File("Earth_Wall.png"));
		}catch(IOException e) {}
		try
		{
			airWall = ImageIO.read(new File("Air_Wall.png"));
		}catch(IOException e) {}
		try
		{
			finalWall = ImageIO.read(new File("Final_Wall.png"));
		}catch(IOException e) {}
	}
	
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public int getType() {return type;}
	
	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}
	public void setW(int w) {this.w = w;}
	public void setL(int l) {this.l = l;}
	public void setType(int type) {this.type = type;}	
	
	public void paint(Graphics g)
	{
		Graphics2D wa = (Graphics2D) g;
		if(type==1)
		{
			wa.drawImage(fireWall, getX(), getY(), getW(), getL(), null);
		}
		else if(type==2)
		{
			wa.drawImage(waterWall, getX(), getY(), getW(), getL(), null);

		}
		else if(type==3)
		{
			wa.drawImage(earthWall, getX(), getY(), getW(), getL(), null);

		}
		else if(type==4)
		{
			wa.drawImage(airWall, getX(), getY(), getW(), getL(), null);

		}
		else
		{
			wa.drawImage(finalWall, getX(), getY(), getW(), getL(), null);
		}
	}
}
