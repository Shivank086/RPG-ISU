import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;
import java.awt.*;

import javax.swing.JPanel;
import javax.swing.event.MouseInputAdapter;

import org.w3c.dom.events.MouseEvent;
public class Menu extends MouseInputAdapter{
	private static Player pl;
	private static String menType = "main", input = "";
	private static int coun, counter = 0, hol = 400, cx = -1, cy = -1, mx, my;
	private static BufferedImage pIconB, pIconF, pIconW, pIconE, pIconA, scroll, scroll_Main, scroll_Upgrade, scroll_Cheat, 
	aIconF, aIconW, aIconE, aIconA, aIconFl, aIconWl, aIconEl, aIconAl, aIconFh, aIconWh, aIconEh, aIconAh, coin, heart, feather, sword = null;
	
	private static Font mWar;
	public Menu(Player pl) {
		this.pl = pl;
		try
		{
			pIconB = ImageIO.read(new File("pIcon_Base.png"));
			pIconF = ImageIO.read(new File("pIcon_Fire.png"));
			pIconW = ImageIO.read(new File("pIcon_Water.png"));
			pIconE = ImageIO.read(new File("pIcon_Earth.png"));
			pIconA = ImageIO.read(new File("pIcon_Air.png"));
			
			scroll = ImageIO.read(new File("ScrollMenu.png"));
			scroll_Main = ImageIO.read(new File("Menu_Main.png"));
			scroll_Cheat = ImageIO.read(new File("Menu_Cheat.png"));
			scroll_Upgrade = ImageIO.read(new File("Menu_Upgrade.png"));
			
			aIconF = ImageIO.read(new File("Fireball.png"));
			aIconW = ImageIO.read(new File("Heal.png"));
			aIconE = ImageIO.read(new File("Rockwall.png"));
			aIconA = ImageIO.read(new File("Windgust.png"));

			aIconFl = ImageIO.read(new File("Fireball_Lock.png"));
			aIconWl = ImageIO.read(new File("Heal_Lock.png"));
			aIconEl = ImageIO.read(new File("Rockwall_Lock.png"));
			aIconAl = ImageIO.read(new File("Windgust_Lock.png"));

			aIconFh = ImageIO.read(new File("Fireball_Hover.png"));
			aIconWh = ImageIO.read(new File("Heal_Hover.png"));
			aIconEh = ImageIO.read(new File("Rockwall_Hover.png"));
			aIconAh = ImageIO.read(new File("Windgust_Hover.png"));
			
			heart = ImageIO.read(new File("Heart.png"));
			feather = ImageIO.read(new File("Feather.png"));
			sword = ImageIO.read(new File("Sword.png"));
			
			coin = ImageIO.read(new File("Coin.png"));
			mWar = Font.createFont(Font.TRUETYPE_FONT, new File("Mechanoid Warrior.ttf"));
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
			ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Mechanoid Warrior.ttf")));
			Thread.sleep(500);
		} catch (FontFormatException e) {e.printStackTrace();} catch (IOException e) {e.printStackTrace();} catch (InterruptedException e) {e.printStackTrace();}	
	}

	public int getCx(){return cx;}
	public int getCy(){return cy;}
	public int getMx(){return mx;}
	public int getMy(){return my;}
	public int getHol(){return hol;}
	public int getCount(){return coun;}
	public String getMenType(){return menType;}
	
	public void setCx(int cx){this.cx = cx;}
	public void setCy(int cy){this.cy = cy;}
	public void setMx(int mx){this.mx = mx;}
	public void setMy(int my){this.my = my;}
	public void setHol(){hol = 400;}
	public void setCount(){coun = 0;}
	public void setMenType(String menType){this.menType = menType;}
	public void setInput(String input){this.input = input;}
	
	
	public static void open(Graphics g) {
		Graphics2D p = (Graphics2D) g;
		p.setColor(Color.BLACK);
		p.fillRect(0, 0, 1500, 720);
		p.setFont(mWar);
		p.setFont(g.getFont().deriveFont(Font.PLAIN, 70));
		
		if(menType.equals("controls"))			menuSettings(p);
		else if(menType.equals("story")) 		coun = menuStory(p, coun);
		else if(menType.equals("upgrade")) 	menuUpgrade(p);
		else if(menType.equals("credits")) 	coun = menuCredits(p, coun);
		else if(menType.equals("quit")) 		menuQuit(p);
		else if(menType.equals("cheat")) 		menuCheat(p);
		else menuMain(p);
		
	}
	public static void menuMain(Graphics2D p){
		input = "";
		p.drawImage(scroll_Main, 45, 60, 1410, 600, null);


		if(mx>=165 && mx<=705 && my>=450 && my<520) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("UPGRADE", 250, 510);
		
		if(mx>=165 && mx<=705 && my>=330 && my<400) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("STORY", 305, 390);
		
		if(mx>=165 && mx<=705 && my>=200 && my<270) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("CONTROLS", 250, 260);
		
		
		if(mx>=805 && mx<=1345 && my>=200 && my<270) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("CREDITS", 910, 260);
		
		if(mx>=805 && mx<=1345 && my>=330 && my<400) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("CHEAT", 950, 390);
		
		if(mx>=805 && mx<=1345 && my>=450 && my<520) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("QUIT", 995, 510);


		if(cx>=165 && cx<=705){
			if(cy>=200 && cy<270){
				cx = -1;
				cy = -1;
				menType = "controls";
			}else if(cy>=330 && cy<400){
				cx = -1;
				cy = -1;
				menType = "story";
			}
			else if(cy>=450 && cy<520){
				cx = -1;
				cy = -1;
				menType = "upgrade";
			}
		}else if(cx>=805 && cx<=1345){
			if(cy>=200 && cy<270){
				cx = -1;
				cy = -1;
				menType = "credits";
			}else if(cy>=330 && cy<400){
				cx = -1;
				cy = -1;
				menType = "cheat";
			}else if(cy>=450 && cy<520){
				cx = -1;
				cy = -1;
				menType = "quit";
			}
		}
	}
	public static void menuCheat(Graphics2D p){
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 60));
		p.drawImage(scroll_Cheat, 45, 60, 1410, 600, null);

		if(my>=190 && my<=260 && mx>=155 && mx<=215) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("A", 164, 246);
		if(my>=190 && my<=260 && mx>=245 && mx<=305) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("B", 255, 246);
		if(my>=190 && my<=260 && mx>=335 && mx<=395) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("C", 345, 246);
		if(my>=190 && my<=260 && mx>=425 && mx<=485) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("D", 435, 246);
		if(my>=190 && my<=260 && mx>=515 && mx<=575) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("E", 525, 246);
		if(my>=190 && my<=260 && mx>=605 && mx<=665) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("F", 615, 246);
		if(my>=190 && my<=260 && mx>=695 && mx<=755) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("G", 705, 246);
		if(my>=190 && my<=260 && mx>=785 && mx<=845) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("H", 795, 246);
		if(my>=190 && my<=260 && mx>=875 && mx<=935) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("I", 895, 246);
		

		if(my>=320 && my<=390 && mx>=155 && mx<=205) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("J", 159, 375);
		if(my>=320 && my<=390 && mx>=235 && mx<=295) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("K", 245, 375);
		if(my>=320 && my<=390 && mx>=325 && mx<=375) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("L", 330, 375);
		if(my>=320 && my<=390 && mx>=405 && mx<=475) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("M", 417, 375);
		if(my>=320 && my<=390 && mx>=505 && mx<=565) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("N", 515, 375);
		if(my>=320 && my<=390 && mx>=595 && mx<=655) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("O", 605, 375);
		if(my>=320 && my<=390 && mx>=685 && mx<=745) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("P", 695, 375);
		if(my>=320 && my<=390 && mx>=775 && mx<=835) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("Q", 785, 375);
		if(my>=320 && my<=390 && mx>=865 && mx<=925) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("R", 875, 375);

		if(my>=450 && my<=520 && mx>=155 && mx<=215) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("S", 164, 504);
		if(my>=450 && my<=520 && mx>=245 && mx<=315) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("T", 260, 504);
		if(my>=450 && my<=520 && mx>=345 && mx<=405) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("U", 355, 504);
		if(my>=450 && my<=520 && mx>=435 && mx<=505) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("V", 448, 504);
		if(my>=450 && my<=520 && mx>=535 && mx<=605) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("W", 547, 504);
		if(my>=450 && my<=520 && mx>=635 && mx<=695) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("X", 642, 504);
		if(my>=450 && my<=520 && mx>=725 && mx<=795) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("Y", 740, 504);
		if(my>=450 && my<=520 && mx>=825 && mx<=885) p.setColor(new Color(255, 191, 0));
		else p.setColor(new Color(70, 70, 70));
		p.drawString("Z", 832, 504);

		if(input.length()<7){
			if(cy>=190 && cy<=260){
				if(cx>=155 && cx<=215){
					cx = -1;
					cy = -1;
					input+="a";
				}else if(cx>=245 && cx<=305){
					cx = -1;
					cy = -1;
					input+="b";
				}else if(cx>=335 && cx<=395){
					cx = -1;
					cy = -1;
					input+="c";
				}else if(cx>=425 && cx<=485){
					cx = -1;
					cy = -1;
					input+="d";
				}else if(cx>=515 && cx<=575){
					cx = -1;
					cy = -1;
					input+="e";
				}else if(cx>=605 && cx<=665){
					cx = -1;
					cy = -1;
					input+="f";
				}else if(cx>=695 && cx<=755){
					cx = -1;
					cy = -1;
					input+="g";
				}else if(cx>=785 && cx<=845){
					cx = -1;
					cy = -1;
					input+="h";
				}else if(cx>=875 && cx<=935){
					cx = -1;
					cy = -1;
					input+="i";
				}
			}else if(cy>=320 && cy<=390){
				if(cx>=155 && cx<=205){
					cx = -1;
					cy = -1;
					input+="j";
				}else if(cx>=235 && cx<=295){
					cx = -1;
					cy = -1;
					input+="k";
				}else if(cx>=325 && cx<=375){
					cx = -1;
					cy = -1;
					input+="l";
				}else if(cx>=405 && cx<=475){
					cx = -1;
					cy = -1;
					input+="m";
				}else if(cx>=505 && cx<=565){
					cx = -1;
					cy = -1;
					input+="n";
				}else if(cx>=595 && cx<=655){
					cx = -1;
					cy = -1;
					input+="o";
				}else if(cx>=685 && cx<=745){
					cx = -1;
					cy = -1;
					input+="p";
				}else if(cx>=775 && cx<=835){
					cx = -1;
					cy = -1;
					input+="q";
				}else if(cx>=865 && cx<=925){
					cx = -1;
					cy = -1;
					input+="r";
				}
			}else if(cy>=450 && cy<=520){
				if(cx>=155 && cx<=215){
					cx = -1;
					cy = -1;
					input+="s";
				}else if(cx>=245 && cx<=315){
					cx = -1;
					cy = -1;
					input+="t";
				}else if(cx>=345 && cx<=405){
					cx = -1;
					cy = -1;
					input+="u";
				}else if(cx>=435 && cx<=505){
					cx = -1;
					cy = -1;
					input+="v";
				}else if(cx>=535 && cx<=605){
					cx = -1;
					cy = -1;
					input+="w";
				}else if(cx>=635 && cx<=695){
					cx = -1;
					cy = -1;
					input+="x";
				}else if(cx>=725 && cx<=795){
					cx = -1;
					cy = -1;
					input+="y";
				}else if(cx>=825 && cx<=885){
					cx = -1;
					cy = -1;
					input+="z";
				}
			}
		}

		p.setColor(new Color(70, 70, 70));
		if(input.length()==7){
			counter++;
			if(input.equals("jackpot")){
				p.drawString("maxed coins", 940, 490);
				pl.setCoins(9999);
			}else if(input.equals("berserk")){
				p.drawString("maxed", 1010, 460);
				p.drawString("damage", 1000, 520);
				pl.setDmg(99);
				pl.setDmgU(5);
			}else if(input.equals("godmode")){
				p.drawString("God Mode", 990, 460);
				p.drawString("enabled", 1000, 520);
				pl.setGodMode(true);
				
			}else p.drawString("Incorrect", 975, 460);
		}
		p.drawString(input, 990, 375);

		if(counter==200){
			input = "";
			counter = 0;
		}

	}
	public static void menuUpgrade(Graphics2D p){
		if(counter>20) counter = 0;
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 75));
		p.drawImage(scroll_Upgrade, 45, 60, 1410, 600, null);
		if(pl.getType() == 0) p.drawImage(pIconB, 80, 205, 400, 400, null);
		else if(pl.getType() == 1) p.drawImage(pIconF, 80, 205, 400, 400, null);
		else if(pl.getType() == 2) p.drawImage(pIconW, 80, 205, 400, 400, null); 
		else if(pl.getType() == 3) p.drawImage(pIconE, 80, 205, 400, 400, null);
		else if(pl.getType() == 4) p.drawImage(pIconA, 80, 205, 400, 400, null);
		if(cx>=1095 && cx<=1185){
			if(cy>=190 && cy<=340) if(buy(50)){
				cx = -1;
				cy = -1;
				pl.setHasF(true);
				pl.setCoins(pl.getCoins()-50);
			}
			if(cy>=380 && cy<=530) if(buy(50)){
				cx = -1;
				cy = -1;
				pl.setHasE(true);
				pl.setCoins(pl.getCoins()-50);
			}
		}else if(cx>=1235 && cx<=1425){
			
			if(cy>=190 && cy<=340) if(buy(50)){
				cx = -1;
				cy = -1;
				pl.setHasW(true);
				pl.setCoins(pl.getCoins()-50);
			}
			if(cy>=380 && cy<=530) if(buy(50)){
				cx = -1;
				cy = -1;
				pl.setHasA(true);
				pl.setCoins(pl.getCoins()-50);
			}
		


		}else if(cx>=975 && cx<=1025){
			if(cy>=290 && cy<=340 && pl.getHpU()<5){
				cx = -1;
				cy = -1;
				if(buy((pl.getHpU()+1)*5)){
					pl.setHpU(pl.getHpU()+1);
					pl.setCoins(pl.getCoins()-(pl.getHpU())*5);
					pl.setHp(pl.getHp()+5);
				}
			}else if(cy>=380 && cy<=430 && pl.getSpdU()<5){
				cx = -1;
				cy = -1;
				if(buy((pl.getSpdU()+1)*5)){
					pl.setSpdU(pl.getSpdU()+1);
					pl.setCoins(pl.getCoins()-(pl.getSpdU())*5);
					pl.setMaxSpd(pl.getMaxSpd()+1);
				}
			}else if(cy>=470 && cy<=520 && pl.getDmgU()<5){
				cx = -1;
				cy = -1;
				if(buy((pl.getDmgU()+1)*5)){
					pl.setDmgU(pl.getDmgU()+1);
					pl.setCoins(pl.getCoins()-(pl.getDmgU())*5);
					pl.setDmg(pl.getDmg()+2);
				}
			}
		}
		p.drawImage(coin, 780, 195, 40, 40, null);
		

		if(mx>=975 && mx<=1025 && my>=290 && my<=340 && pl.getHpU()<5){
			p.setFont(p.getFont().deriveFont(Font.PLAIN, 50));
			p.setColor(new Color(70, 70, 70));
			p.drawString("X "+(pl.getHpU()+1)*5, 860, 232);
			p.setColor(Color.BLACK);
			if(buy((pl.getHpU()+1)*5)) p.drawString("Health Up", 410, 232);
			else p.drawString("Not Enough", 410, 232);
			p.setColor(new Color(255, 191, 0));
		}else p.setColor(new Color(70, 70, 70));
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 75));
		p.drawString("+", 975, 341);
		
		if(mx>=975 && mx<=1025 && my>=380 && my<=430 && pl.getSpdU()<5){
			p.setFont(p.getFont().deriveFont(Font.PLAIN, 50));
			p.setColor(new Color(70, 70, 70));
			p.drawString("x "+(pl.getSpdU()+1)*5, 860, 232);
			p.setColor(Color.BLACK);
			if(buy((pl.getSpdU()+1)*5)) p.drawString("Speed Up", 410, 232);
			else p.drawString("Not Enough", 410, 232);
			p.setColor(new Color(255, 191, 0));
		}else p.setColor(new Color(70, 70, 70));
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 75));
		p.drawString("+", 975, 431);
		
		if(mx>=975 && mx<=1025 && my>=470 && my<=520 && pl.getDmgU()<5){
			p.setFont(p.getFont().deriveFont(Font.PLAIN, 50));
			p.setColor(new Color(70, 70, 70));
			p.drawString("x "+(pl.getDmgU()+1)*5, 860, 232);
			p.setColor(Color.BLACK);
			if(buy((pl.getDmgU()+1)*5)) p.drawString("Damage Up", 410, 232);
			else p.drawString("Not Enough", 410, 232);
			p.setColor(new Color(255, 191, 0));
		}else p.setColor(new Color(70, 70, 70));
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 75));
		p.drawString("+", 975, 521);
		
		p.setColor(Color.RED);
		if(pl.getHpU()>0) p.fillRect(495, 290, 80, 50);
		if(pl.getHpU()>1) p.fillRect(585, 290, 80, 50);
		if(pl.getHpU()>2) p.fillRect(675, 290, 80, 50);
		if(pl.getHpU()>3) p.fillRect(765, 290, 80, 50);
		if(pl.getHpU()>4) p.fillRect(855, 290, 80, 50);

		p.setColor(new Color(0, 162, 255));
		if(pl.getSpdU()>0) p.fillRect(495, 380, 80, 50);
		if(pl.getSpdU()>1) p.fillRect(585, 380, 80, 50);
		if(pl.getSpdU()>2) p.fillRect(675, 380, 80, 50);
		if(pl.getSpdU()>3) p.fillRect(765, 380, 80, 50);
		if(pl.getSpdU()>4) p.fillRect(855, 380, 80, 50);

		p.setColor(new Color(51, 156, 53));
		if(pl.getDmgU()>0) p.fillRect(495, 470, 80, 50);
		if(pl.getDmgU()>1) p.fillRect(585, 470, 80, 50);
		if(pl.getDmgU()>2) p.fillRect(675, 470, 80, 50);
		if(pl.getDmgU()>3) p.fillRect(765, 470, 80, 50);
		if(pl.getDmgU()>4) p.fillRect(855, 470, 80, 50);

		p.setColor(Color.BLACK);
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 40));
		p.drawImage(sword, 400, 460, 70, 70, null);
		p.drawImage(feather, 400, 370, 70, 70, null);
		p.drawImage(heart, 400, 280, 70, 70, null);
		p.drawImage(coin, 150, 160, 50, 50, null);
		p.drawString(" x "+pl.getCoins(), 190, 198);


		
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 50));
		p.setColor(new Color(70, 70, 70));

		if(pl.getHasF())p.drawImage(aIconF, 1105, 200, 70, 130, null);
		else if(mx>=1095 && mx<=1185 && my>=190 && my<=340){
			p.drawImage(aIconFh, 1105, 200, 70, 130, null);
			p.drawString("x 50", 860, 232);
			p.setColor(Color.BLACK);
			if(buy(50)) p.drawString("Fireball", 410, 232);
			else p.drawString("Not Enough", 410, 232);
		}
		else p.drawImage(aIconFl, 1105, 200, 70, 130, null);


		
		p.setColor(new Color(70, 70, 70));
		if(pl.getHasW()) p.drawImage(aIconW, 1245, 200, 70, 130, null);
		else if(mx>=1235 && mx<=1425 && my>=190 && my<=340){
			p.drawImage(aIconWh, 1245, 200, 70, 130, null);
			p.drawString("x 50", 860, 232);
			p.setColor(Color.BLACK);
			if(buy(50)) p.drawString("Heal", 410, 232);
			else p.drawString("Not Enough", 410, 232);
		}
		else p.drawImage(aIconWl, 1245, 200, 70, 130, null);
		

		
		p.setColor(new Color(70, 70, 70));
		if(pl.getHasE()) p.drawImage(aIconE, 1105, 390, 70, 130, null);
		else if(mx>=1095 && mx<=1185 && my>=380 && my<=530){
			p.drawImage(aIconEh, 1105, 390, 70, 130, null);
			p.drawString("x 50", 860, 232);
			p.setColor(Color.BLACK);
			if(buy(50)) p.drawString("Rumble", 410, 232);
			else p.drawString("Not Enough", 410, 232);
		}
		else p.drawImage(aIconEl, 1105, 390, 70, 130, null);
		

		
		p.setColor(new Color(70, 70, 70));
		if(pl.getHasA()) p.drawImage(aIconA, 1245, 390, 70, 130, null);
		else if(mx>=1235 && mx<=1425 && my>=380 && my<=530){
			p.drawImage(aIconAh, 1245, 390, 70, 130, null);
			p.drawString("x 50", 860, 232);
			p.setColor(Color.BLACK);
			if(buy(50)) p.drawString("Windgust", 410, 232);
			else p.drawString("Not Enough", 410, 232);
		}
		else p.drawImage(aIconAl, 1245, 390, 70, 130, null);

	}
	public static int menuStory(Graphics2D p, int count){
		if((count >=250 && hol > -310) || (count>=9000 && hol != -1050)) hol-=5;
		count+=5;
		p.setColor(Color.WHITE);
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 80));
		p.drawString("The legend of caelum", 210, hol);
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 35));
		p.drawString("before time had a name, there were the gods of light and ", 20, hol+345);
		p.drawString("darkness,locked in an eternal battle", 20, hol+375);
		p.drawString("Eventually, the god of darkness became cunning, and split the ", 20, hol+425);
		p.drawString("gods' powers into four elements", 20, hol+455);
		p.drawString("The god of darkness powers took physical form as his four ", 20, hol+505);
		p.drawString("generals, while it became the demon lord gehenna", 20, hol+535);
		p.drawString("suprised, gehenna and his four generals wounds the godess", 20, hol+585);
		p.drawString("of light, who could not control her powers anymore", 20, hol+615);
		p.drawString("The godess of light had to flee and hide, letting gehenna ", 20, hol+665);
		p.drawString("run amok across the world", 20, hol+695);
		p.drawString("Centuries pass, and the demon king has concqured the world,", 20, hol+745);
		p.drawString("building a tower where caelum's home town once was", 20, hol+775);
		p.drawString("Caelum was taken prisoner, and was forced to grow up in", 20, hol+825);
		p.drawString("the dungeon of the tower, slowly biding his time", 20, hol+855);
		p.drawString("Eventually, the god of light returns, and gifts it's", 20, hol+905);
		p.drawString("elemental powers to Caelum, as it is unable to use them anymore", 20, hol+935);
		p.drawString("It is now Caelum's mission to break free of the dungeon, climb ", 20, hol+985);
		p.drawString("the tower, and free the world of gehenna and it's four generals", 20, hol+1015);
		p.drawString("[PRESS Z TO CONTINUE]",500, hol+1400);
		return count;
	}
	public static int menuCredits(Graphics2D p, int count){
		if((count >= 250 && hol > -310) || (count>=1500 && hol != -1050)) hol-=5;
		count+=5;
		p.setColor(Color.WHITE);
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 80));
		p.drawString("credits", 570, hol);
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 35));
		p.drawString("Made by:", 660, hol+665);
		p.drawString("Shivank & Daevik",570, hol+700);
		p.drawString("Thanks for playing",540, hol+1400);
		p.drawString("[PRESS Z TO CONTINUE]",500, hol+1435);
		return count;
	}
	public static void menuSettings(Graphics2D p){
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 40));
		p.drawImage(scroll, 45, 60, 1410, 600, null);
		p.drawString("[z] -- open/close menu", 	150, 210);
		p.drawString("[x] -- pickup item", 		150, 250);
		p.drawString("[c] -- Attack", 			150, 290);
		p.drawString("[space] -- Ability", 		150, 330);
		
		p.drawString("[UP ARROW] -- jump", 			150, 400);
		p.drawString("[L ARROW] -- move left", 		150, 440);
		p.drawString("[R ARROW] -- move right", 		150, 480);
		
		p.drawString("[1] -- fire form", 		770, 210);
		p.drawString("[2] -- water form", 		770, 250);
		p.drawString("[3] -- earth form", 		770, 290);
		p.drawString("[4] -- air form", 		770, 330);

		p.drawString("Gameplay:", 				770, 400);
		p.setFont(p.getFont().deriveFont(Font.PLAIN, 25));
		p.drawString("Each enemy has an element, which it's", 		770, 430);
		p.drawString("damage is based on. If you are of the", 		770, 455);
		p.drawString("weaker element, you take more damage", 		770, 480);
		p.drawString("from it, and you deal more damage if", 		770, 505);
		p.drawString("you are of the stronger element", 			770, 530);

	}
	public static void menuQuit(Graphics2D p){System.exit(0);}
	public static boolean buy(int price) {return pl.getCoins()>=price;}
}
