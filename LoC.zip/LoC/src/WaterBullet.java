import java.awt.BasicStroke;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class WaterBullet 
{
	private int x, y, xa, ya, dmg;
	public WaterBullet(int x, int y, int xa, int ya, int dmg)
	{
		this.x = x;
		this.y = y;
		this.xa = xa;
		this.ya = ya;
		this.dmg = dmg;
	}
	
	public int getX() {return x;}
	public int getY() {return y;}
	public int getXa() {return xa;}
	public int getYa() {return ya;}
	public int getDmg() {return dmg;}
	
	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}
	public void setXa(int xa) {this.xa = xa;}
	public void setYa(int ya) {this.ya = ya;}
	public void setDmg(int dmg) {this.dmg = dmg;}
	
	public void paint(Graphics g)
	{
		Graphics2D w = (Graphics2D) g;
		w.setStroke(new BasicStroke(10));
		w.setColor(Color.CYAN);
		w.drawLine(getX(), getY(), getX()+getXa()/2, getY()+getYa()/2);
		w.setStroke(new BasicStroke(1));
	}
	
	public void move()
	{
		setX(getX()+getXa());
		setY(getY()+getYa());
	}
	
	public boolean wCollision(Wall w)
	{
		int x2 = getX()+getXa();
		int y2 = getY()+getYa();
		return((w.getX()<x2&&x2<w.getX()+w.getW())&&(w.getY()<y2&&y2<w.getY()+w.getL()));
	}
	
	public boolean pCollision(Player p)
	{
		int x2 = getX()+getXa();
		int y2 = getY()+getYa();
		return((p.getX()<x2&&x2<p.getX()+p.getW())&&(p.getY()<y2&&y2<p.getY()+p.getL()));
	}
}
