import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.event.MouseInputAdapter;

import java.util.*;
import java.awt.image.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import java.util.*;
import java.awt.image.*;

public class Interface extends JPanel
{
	public Level l;
	public static Player pl = new Player (200, 200, 50, 60);
	public Key k = new Key(200, 200, 50, 32, false);
	public ArrayList<Goober> goobs = new ArrayList<Goober>();
	public ArrayList<Coin> coins = new ArrayList<Coin>();
	public ArrayList<Fireball> fireballs = new ArrayList<Fireball>();
	public ArrayList<WaterBullet> waterbullets = new ArrayList<WaterBullet>();
	public ArrayList<Rock> rocks = new ArrayList<Rock>();
	public ArrayList<FirePillar> firepillars = new ArrayList<FirePillar>();
	public ArrayList<Stalactite> stalactites = new ArrayList<Stalactite>();
	public ArrayList<Cloud> clouds = new ArrayList<Cloud>();
	public Water wat = new Water(false);
	public Ardinium ar = new Ardinium(400, 200, 102, 168, 5, 5, 50, false);
	public Aquigo aq = new Aquigo(650, 200, 200, 200, 100, false, false);
	public Petrissima pe = new Petrissima(90, 570, 90, 90, 2, 150, false);
	public Volantinea v = new Volantinea(60, 60, 150, 120, 0, 0, 50, 20, false);
	public Gehenna ge = new Gehenna(60, 600, 60, 60, 20, 1000, false);
	public Bossbar b = new Bossbar(300, 80, 900, 20, 0, 0, false);
	public boolean isAtk = false;
	public boolean showCoins = false;
	public boolean showKey = false;
	public boolean doorOpen = false;
	public boolean pickUp = false;
	public static Victory vic = new Victory();
	public static boolean reset = false;
	public boolean defeatFire = false, defeatWater = false, defeatEarth = false, defeatAir = false, defeatFinal = false;
	public static boolean menu = false;
	public boolean menuHasOpened = false;
	public static Menu m = new Menu(pl);
	public static Title t = new Title(m);
	public static GUI gui = new GUI(pl);
	public static boolean viewDS = false;
	public int respawnCounter = 0;
	public DeathScreen ds = new DeathScreen();
	public int atkCooldown = 0;
	public int afCooldown = 75;
	public int aqCooldown = 700;
	public int wbCooldown = 200;
	public int rkCooldown = 200;
	public int pwCooldown = 5000;
	public int vCooldown = 400;
	public BufferedImage fireBg = null, waterBg = null, earthBg = null, airBg = null, finalBg = null, tutorial = null;
	public Interface()
	{
		setLevel(0);
		try
		{
			fireBg = ImageIO.read(new File("FireBG.png"));
			waterBg = ImageIO.read(new File("WaterBG.png"));
			airBg = ImageIO.read(new File("AirBG.png"));
			finalBg = ImageIO.read(new File("FinalBG.png"));
			earthBg = ImageIO.read(new File("EarthBG.png"));
			tutorial = ImageIO.read(new File("Dungeon.png"));
		}catch(IOException e) {}
		addKeyListener(new KeyListener() 
		{
			 @Override
			 public void keyTyped(KeyEvent e) {}
			 @Override
			 public void keyReleased(KeyEvent e){
				 pl.keyReleased(e);
				 keyRlsd(e);
			 }
			 @Override
			 public void keyPressed(KeyEvent e){
				pl.keyPressed(e);
				keyPrsd(e);
			 }
		}); 
		addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
				if(menu){
                	m.setCx(e.getX());
                	m.setCy(e.getY());
					//System.out.println(m.getCx());
					//System.out.println(m.getCy());
				}
				
				if(t.getTitle()){
                	t.setCx(e.getX());
                	t.setCy(e.getY());
					//System.out.println(t.getCx());
					//System.out.println(t.getCy());
				}
				if(vic.getVictory()){
                	vic.setCx(e.getX());
                	vic.setCy(e.getY());
					//System.out.println(vic.getCx());
					//System.out.println(vic.getCy());
				}
            }
        });
		addMouseMotionListener(new MouseMotionListener(){
            @Override
            public void mouseMoved(MouseEvent e) {
				if(menu){
                	m.setMx(e.getX());
                	m.setMy(e.getY());
				}
				if(t.getTitle()){
                	t.setMx(e.getX());
                	t.setMy(e.getY());
				}
				if(vic.getVictory()){
                	vic.setMx(e.getX());
                	vic.setMy(e.getY());
				}
			}
			@Override
			public void mouseDragged(MouseEvent e) {
			}
        });
		setFocusable(true);
	}
	public void keyPrsd(KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_C){
			isAtk = true;
			pl.setIsAttacking(true);
		}
		if (e.getKeyCode() == KeyEvent.VK_X) pickUp = true;
		if (e.getKeyCode() == KeyEvent.VK_X) reset = true;
	}
	
	public void keyRlsd(KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_C){
			isAtk = false;
			pl.setIsAttacking(false);
		}
		if (e.getKeyCode() == KeyEvent.VK_X) pickUp = false;
		if (e.getKeyCode() == KeyEvent.VK_Z){
			if(!t.getTitle()){
				menu = !menu;
				m.setMenType("main");
			}
		}
		if (e.getKeyCode() == KeyEvent.VK_SPACE) {
			if(gui.getCount()==570){
				if((pl.getType() == 1 && pl.getHasF()) || (pl.getType() == 2 && pl.getHasW()) || (pl.getType() == 3 && pl.getHasE()) || (pl.getType() == 4 && pl.getHasA())){
					gui.setCount(0);
				}
				if(pl.getType() == 1 && pl.getHasF())fireballs.add(new Fireball(pl.getX()+(pl.getW()/Math.abs(pl.getW()))*70, pl.getY()+15,57, 33, (int)(pl.getSpd()*1.5), 2-(pl.getW()/Math.abs(pl.getW())), pl.getDmgA()));
				else if(pl.getType() == 2 && pl.getHasW()) pl.abbWater();
				else if(pl.getType() == 3 && pl.getHasE()) pl.abbEarth(gui.getCount());
				else if(pl.getType() == 4 && pl.getHasA()) pl.abbAir(gui.getCount());
			}
			
		}
		if(!menu){
			/*if (e.getKeyCode() == KeyEvent.VK_0){
				pl.setType(0);
			}*/
			if (e.getKeyCode() == KeyEvent.VK_1){
				pl.setType(1);
				pl.setCounterT(10);
			}
			if (e.getKeyCode() == KeyEvent.VK_2){
				pl.setType(2);
				pl.setCounterT(10);
			}
			if (e.getKeyCode() == KeyEvent.VK_3){
				pl.setType(3);
				pl.setCounterT(10);
			}
			if (e.getKeyCode() == KeyEvent.VK_4){
				pl.setType(4);
				pl.setCounterT(10);
			}
		}
	}
	
	@Override
	public void paint(Graphics g) 
	{
		super.paint(g); 
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				 RenderingHints.VALUE_ANTIALIAS_ON);
		if(l.getLevel()==0) g2d.drawImage(tutorial, 60, 60, 1380, 600, null);
		else if(l.getType()==1) g2d.drawImage(fireBg, 60, 60, 1380, 600, null);
		else if(l.getType()==2) g2d.drawImage(waterBg, 60, 60, 1380, 600, null);
		else if(l.getType()==3) g2d.drawImage(earthBg, 60, 60, 1380, 600, null);
		else if(l.getType()==4) g2d.drawImage(airBg, 60, 60, 1380, 600, null);
		else  g2d.drawImage(finalBg, 0, 0, 1500, 720, null);
		for(Stalactite s: stalactites) s.paint(g2d);
		l.paint(g2d, this);
		gui.paint(g2d);
		if(wat.getVisible()) wat.paint(g2d);
		for(Goober gb: goobs)
		{
			gb.paint(g2d);
		}
		if(ar.getVisible()) ar.paint(g2d);
		for(WaterBullet w: waterbullets)
		{
			w.paint(g2d);
		}
		if(aq.getS()) aq.paint(g2d);
		if(pe.getVisible()) pe.paint(g2d);
		if(v.getVisible()) v.paint(g2d);
		if(ge.getVisible()) ge.paint(g2d, pl);
		for(FirePillar fp: firepillars) fp.paint(g2d);
		pl.paint(g2d);
		Iterator<Rock> itr = rocks.iterator();
		while(itr.hasNext())
		{
			Rock r = itr.next();
			r.paint(g2d);
		}
		for(Fireball f: fireballs) f.paint(g2d);
		for(Coin c: coins) c.paint(g2d);
		k.paint(g2d);
		for(Cloud c: clouds) c.paint(g2d);
		if(b.getS()) b.paint(g2d);
		if(viewDS) 
		{
			ds.paint(g2d);
			respawnCounter--;
			if(respawnCounter<0) viewDS = false;
		}
		else if(menu) 
		{
			m.open(g2d);
			menuHasOpened = true;
		}
		else{
			m.setHol();
			m.setCount();
		}
		if(t.getTitle()) t.open(g2d);
		if(vic.getVictory()) vic.open(g2d);
	}
	public static void main(String[] args) throws InterruptedException 
	{
		JFrame frame = new JFrame("Legend of Caelum");
		Interface p = new Interface();
		frame.add(p);
		frame.setSize(1516, 759);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		if(reset)
		{
			p = new Interface();
			reset = false;
		}
		while (true)
		{
			if(!menu && !viewDS && !t.getTitle() && !vic.getVictory()) p.move(); 			
			p.repaint(); 
			Thread.sleep(10); 
		}
	}
	public void move()
	{
		if(l.getLevel()>=26) vic.setVictory(true);
		if(l.getLevel()==0) l.move(this);
		pl.move(l.getWalls(), gui.getCount());
		if(wat.pCollision(pl)) pl.setSpd(pl.getMaxSpd()/2);
		if(pl.getIsEarAbb()) pl.setDmgA(pl.getDmg()+10);
		else pl.setDmgA(pl.getDmg());
		if(pl.getIsAirAbb()) pl.setSpd(pl.getMaxSpd()+10);

		if(!wat.pCollision(pl) && !pl.getIsAirAbb()) pl.setSpd(pl.getMaxSpd());
		if(pl.getIsAirAbb()) pl.setSpd(pl.getMaxSpd()+10);
		if(pl.getHp()<1) plDies();
		Iterator<Goober> itr = goobs.iterator();
		while (itr.hasNext()) 
		{ 
			Goober gb = itr.next(); 
			
			if (gb.getHp()<1) 
			{
				if(goobs.size()==1&&(l.getLevel()%5!=0||l.getLevel()==0))
				{
					k.setX(gb.getX());
					k.setY(gb.getY());
					showKey = true;
				}
				coins.add(new Coin(gb.getX(), gb.getY(), 30, (int)(5*gb.getSize()-2)));
				itr.remove();   
			}
		}
		Iterator<Coin> itrC = coins.iterator();
		while (itrC.hasNext()) 
		{ 
			Coin c = itrC.next(); 
			//System.out.println(c.pCollision(pl) + " " + pickUp);
			if (c.pCollision(pl)&&pickUp) 
			{
				
				pl.setCoins(pl.getCoins()+c.getVal());
				itrC.remove(); 
			}
		}
		Iterator<Fireball> itrF = fireballs.iterator();
		while (itrF.hasNext()) 
		{ 
			boolean pCollided = false, wCollided = false, gCollided = false;
			Fireball f = itrF.next(); 
			if (f.pCollision(pl)) 
			{
				if(pl.getType()==3) pl.setHp(pl.getHp()-f.getDmg()-10);
				else  pl.setHp(pl.getHp()-f.getDmg());
				itrF.remove();
				pCollided = true;
			}
			if(!pCollided)
			{
				for(Wall w: l.getWalls())
				{
					if(f.wCollision(w)) 
					{
						itrF.remove();
						wCollided = true;
						break;
					}
				}
				if(!wCollided)
				{
					for(Goober g: goobs)
					{
						if(f.gCollision(g)) 
						{
							if(g.getType()==3) g.setHp(g.getHp()-f.getDmg()*2);
							else  g.setHp(g.getHp()-f.getDmg());
							gCollided = true;
							itrF.remove();
							break;
						}
					}
					if(!gCollided)
					{
						if(f.geCollision(ge)&&ge.getVisible())
						{
							if(ge.getType()==3)
							{
								ge.setHp(ge.getHp()-f.getDmg()*2);
							}
							itrF.remove();	
						}
						else if(f.arCollision(ar) && ar.getVisible()) itrF.remove();
						else if(f.aqCollision(aq) &&ar.getVisible())
						{
							itrF.remove();
							aq.setHp(aq.getHp()-f.getDmg());
						}
						else if(f.voCollision(v) && l.getLevel()==15){
							itrF.remove();
							v.setHp(v.getHp()-f.getDmg());
						}
						else if(f.peCollision(pe) && l.getLevel()==20) itrF.remove();
					}
				}
			}
		}
		Iterator<Stalactite> itrS = stalactites.iterator();
		while (itrS.hasNext()) 
		{ 
			boolean pCollided = false;
			Stalactite s = itrS.next(); 
			if (s.pCollision(pl)) 
			{
				pl.setHp(pl.getHp()-s.getDmg());
				itrS.remove();
				pCollided = true;
			}
			if(!pCollided)
			{
				for(Wall w: l.getWalls())
				{
					if(s.wCollision(w)) 
					{
						itrS.remove();
						break;
					}
				}
			}
		}
		if(l.getLevel()>10&&l.getLevel()<16&&stalactites.isEmpty()) summonStalactites(l.getLevel());
		Iterator<WaterBullet> itrW = waterbullets.iterator();
		while (itrW.hasNext()) 
		{ 
			boolean pCollided = false;
			WaterBullet w = itrW.next(); 
			if (w.pCollision(pl)) 
			{
				pl.setHp(pl.getHp()-w.getDmg());
				itrW.remove();
				pCollided = true;
			}
			if(!pCollided)
			{
				for(Wall wa: l.getWalls())
				{
					if(w.wCollision(wa)) 
					{
						itrW.remove();
						break;
					}
				}
			}
		}
		Iterator<Rock> itrR  = rocks.iterator();
		while (itrR.hasNext()) 
		{ 
			boolean pCollided = false;
			boolean bCollided = false;
			Rock r = itrR.next(); 
			if (r.plCollision(pl)) 
			{
				pl.setHp(pl.getHp()-r.getDmg());
				itrR.remove();
				pCollided = true;
			}
			if(!pCollided)
			{
				if(r.bCollision())
				{
					if(l.getLevel()!=0)goobs.add(new Goober(3, 3*0.2+0.8, r.getX(), 600));
					itrR.remove();
					bCollided = true;
				}
				if(!bCollided)
				{
					if(r.peCollision(pe))
					{
						pe.setHp(pe.getHp()-r.getDmg());
						itrR.remove();
					}
				}
			}
		}
		for(FirePillar fp: firepillars) 
		{
			fp.move();
			if(fp.pCollision(pl)) 
			{
				pl.setHp(pl.getHp()-5);
				fp.setTimer(100);
				fp.setType(0);
			}
		}
		for(Fireball f: fireballs) f.move();
		for(Stalactite s: stalactites) s.move();
		for(WaterBullet w: waterbullets) w.move();
		for(Cloud c: clouds) c.move();
		for(Rock r: rocks) 
		{
			int rCenterX = (2*r.getX()+r.getD())/2;
			int plCenterX = (2*pl.getX()+Math.abs(pl.getW()))/2;
			int rCenterY = (2*r.getY()+r.getD())/2;
			int plCenterY = (2*pl.getY()+pl.getL())/2;
			int hypo =(int)(Math.sqrt(Math.pow(plCenterX - rCenterX, 2)+Math.pow(plCenterY - rCenterY, 2)));
			if(atkCooldown<=0&&isAtk&&hypo<80) 
			{
				atkCooldown = 50;
				r.setXa(r.getXa()*-1);
			}
			r.move();

		}
		if(aq.getS())
		{
			if(!b.getS())
			{
				b.setMaxHp(aq.getHp());
				b.setType(2);
				b.setS(true);
				spawn(3, 2);
			}
			aq.setSh(goobs.size()!=0);
			b.setHp(aq.getHp());
			int aqCenterX = (2*aq.getX()+aq.getW())/2;
			int plCenterX = (2*pl.getX()+Math.abs(pl.getW()))/2;
			int aqCenterY = (2*aq.getY()+aq.getL())/2;
			int plCenterY = (2*pl.getY()+pl.getL())/2;
			int hypo =(int)(Math.sqrt(Math.pow(plCenterX - aqCenterX, 2)+Math.pow(plCenterY - aqCenterY, 2)));
			if(atkCooldown<=0&&isAtk&&hypo<170&&!aq.getSh()) 
			{
				atkCooldown = 50;
				if(pl.getType()==4)aq.setHp(aq.getHp()-(int)(pl.getDmg()*1.5));
				else aq.setHp(aq.getHp()-(pl.getDmg()));
			}
			if(aq.getHp()<1)
			{
				k.setX(aq.getX());
				k.setY(630);
				showKey = true;
				coins.add(new Coin(aq.getX(), 615, 40, 30));
				aq.setS(false);
				b.setS(false);
				defeatWater = true;
			}
			if(!aq.getSh())
			{
				if(aqCooldown>0)
				{
					aqCooldown--;
				}
				else
				{
					spawn((int)(Math.random()*3+2), 2);	
					aqCooldown = 700; 
				}
			}
			if(wbCooldown<=0)
			{
				if(!aq.getSh())
				{
					int dx = plCenterX - aqCenterX;
					int dy = plCenterY - aqCenterY;
					int hyp = (int)(Math.round(Math.hypot(dx, dy)));
					waterbullets.add(new WaterBullet(aqCenterX, aqCenterY, 10*dx/hyp, 10*dy/hyp, 2));
					wbCooldown = 200;
				}
			}
			else
			{
				wbCooldown--;
			}
		}

		if(ar.getVisible())
		{
			if(!b.getS())
			{
				b.setMaxHp(ar.getHp());
				b.setType(1);
				b.setS(true);
			}
			b.setHp(ar.getHp());
			ar.move();
			int aCenterX = (2*ar.getX()+ar.getW())/2;
			int plrCenterX = (2*pl.getX()+Math.abs(pl.getW()))/2;
			int aCenterY = (2*ar.getY()+ar.getL())/2;
			int plrCenterY = (2*pl.getY()+pl.getL())/2;
			int hypoar =(int)(Math.sqrt(Math.pow(plrCenterX - aCenterX, 2)+Math.pow(plrCenterY - aCenterY, 2)));
			//System.out.println((atkCooldown<=0) +" " + isAtk + " " + (hypo<80) );
			if(atkCooldown<=0&&isAtk&&hypoar<100) 
			{
				atkCooldown = 50;
				if(pl.getType()==1)ar.setHp(ar.getHp()-(int)(pl.getDmg()*1.5));
				else ar.setHp(ar.getHp()-(pl.getDmg()));
			}
			if(ar.getHp()<1)
			{
				k.setX(ar.getX());
				k.setY(630);
				showKey = true;
				coins.add(new Coin(ar.getX(), 615, 40, 30));
				ar.setVisible(false);
				b.setS(false);
				defeatFire = true;
			}
			if(afCooldown<=0) 
			{
				if(ar.getY()<300)
				{	
					fireballs.add(new Fireball(ar.getX()+ar.getW()/4, ar.getY()+ar.getL()*3/2, ar.getW()/2, ar.getL()/2, 5, 2, 10));
					afCooldown = 75;
				}
			}
			else
			{
				afCooldown--;
			}
		}
		if(pe.getVisible())
		{
			if(!b.getS())
			{
				b.setMaxHp(pe.getHp());
				b.setType(3);
				b.setS(true);
			}
			b.setHp(pe.getHp());
			pe.move();
			if(pe.getHp()<1)
			{
				goobs.clear();
				k.setX(pe.getX());
				k.setY(630);
				showKey = true;
				coins.add(new Coin(pe.getX(), 615, 40, 30));
				pe.setVisible(false);
				b.setS(false);
				defeatEarth = true;
			}
			if(rkCooldown<=0) 
			{	
				int plCenterX = pl.getX() + Math.abs(pl.getW())/2;
				int peCenterX = pe.getX() + pe.getW()/2;
				int size = (int)(Math.random()*15)+30;
				if(plCenterX<peCenterX) rocks.add(new Rock(pe.getX()-size-5, 600+(60-size)/2, size, -6));
				else rocks.add(new Rock(pe.getX()+pe.getW()+size+5, 600+(60-size)/2, size, 6));;
				rkCooldown = 200;
			}
			else
			{
				rkCooldown--;
			}
		}
		if(v.getVisible())
		{
			if(!b.getS())
			{
				b.setMaxHp(v.getHp());
				b.setType(4);
				b.setS(true);
				int plCenterX = (2*pl.getX()+Math.abs(pl.getW()))/2;
				if(plCenterX-v.getW()/2<60) v.setX(60);
				else if(plCenterX+v.getW()/2>1440) v.setX(1440-v.getW());
				else v.setX(plCenterX-v.getW()/2);
			}
			b.setHp(v.getHp());
			v.move(pl);
			int vCenterX = (2*v.getX()+v.getW())/2;
			int plrCenterX = (2*pl.getX()+Math.abs(pl.getW()))/2;
			int vCenterY = (2*v.getY()+v.getL())/2;
			int plrCenterY = (2*pl.getY()+pl.getL())/2;
			int hypov =(int)(Math.sqrt(Math.pow(plrCenterX - vCenterX, 2)+Math.pow(plrCenterY - vCenterY, 2)));
			if(v.getY()>500&&goobs.size()==0) spawn(3, 4);
			if(atkCooldown<=0&&isAtk&&hypov<170) 
			{
				atkCooldown = 50;
				if(pl.getType()==3)v.setHp(v.getHp()-(int)(pl.getDmg()*1.5));
				else v.setHp(v.getHp()-(pl.getDmg()));
			}
			if(v.pCollide(pl)&&vCooldown<1)
			{
				pl.setHp(pl.getHp()-v.getDmg());
				vCooldown = 400;
			}
			if(v.getHp()<1)
			{
				k.setX(ar.getX());
				k.setY(630);
				showKey = true;
				coins.add(new Coin(v.getX(), 615, 40, 30));
				v.setVisible(false);
				b.setS(false);
				defeatAir = true;
				goobs.clear();
			}
			vCooldown--;
		}
		if(showKey)
		{
			if(k.pCollision(pl)&&pickUp) 
			{
				l.getDoor().setOpen(true);
				showKey = false;
			}
		}
		if(ge.getVisible())
		{
			if(!b.getS())
			{
				b.setMaxHp(ge.getHp());
				b.setType(5);
				b.setS(true);
			}
			b.setHp(ge.getHp());
			ge.move(pl, fireballs);
			b.setType(ge.getType());
			int geCenterX = (2*ge.getX()+ge.getW())/2;
			int plCenterX = (2*pl.getX()+Math.abs(pl.getW()))/2;
			int geCenterY = (2*ge.getY()+ge.getL())/2;
			int plCenterY = (2*pl.getY()+pl.getL())/2;
			int hypo =(int)(Math.sqrt(Math.pow(plCenterX - geCenterX, 2)+Math.pow(plCenterY - geCenterY, 2)));
			if(atkCooldown<=0&&isAtk&&hypo<160) 
			{
				atkCooldown = 50;
				if((pl.getType()==1&&ge.getType()==3)||(pl.getType()==2&&ge.getType()==1)||(pl.getType()==3&&ge.getType()==4)||(pl.getType()==4&&ge.getType()==2))ge.setHp(ge.getHp()-(pl.getDmg()*2));
			}
			if(ge.getHp()<1)
			{
				k.setX(aq.getX());
				k.setY(630);
				showKey = true;
				coins.add(new Coin(aq.getX(), 615, 40, 1000));
				ge.setVisible(false);
				b.setS(false);
				defeatFinal = true;
			}
		}
		if(atkCooldown>0)atkCooldown --;
		for(Goober gb: goobs)
		{
			//System.out.println("Cooldown: " + atkCooldown);
			//System.out.println(gb.getHp());
			//System.out.println(atkCooldown);
			//System.out.println(gb.getHp());
			int gbCenterX = (2*gb.getX()+gb.getDim())/2;
			int plCenterX = (2*pl.getX()+Math.abs(pl.getW()))/2;
			int gbCenterY = (2*gb.getY()+gb.getDim())/2;
			int plCenterY = (2*pl.getY()+pl.getL())/2;
			int hypo =(int)(Math.sqrt(Math.pow(plCenterX - gbCenterX, 2)+Math.pow(plCenterY - gbCenterY, 2)));
			//System.out.println(hypo);
			if(atkCooldown<=0&&isAtk&&hypo<80) 
			{
				atkCooldown = 50;
				if(pl.getType()==1&&gb.getType()==3)gb.setHp(gb.getHp()-(int)(pl.getDmg()*1.5));
				else if(pl.getType()==2&&gb.getType()==1)gb.setHp(gb.getHp()-(int)(pl.getDmg()*1.5));
				else if(pl.getType()==3&&gb.getType()==4)gb.setHp(gb.getHp()-(int)(pl.getDmg()*1.5));
				else if(pl.getType()==4&&gb.getType()==2)gb.setHp(gb.getHp()-(int)(pl.getDmg()*1.5));
				else gb.setHp(gb.getHp()-(pl.getDmg()));
				if(pl.getXa()==0) gb.setSpd(gb.getSpd()*-1);
				else
				{
					int m = pl.getXa()*gb.getSpd();
					if(gb.getSpd()>0)gb.setSpd(gb.getSpd()*m/Math.abs(m));
				}
			}
			gb.setCooldown(gb.getCooldown()-1);
			gb.move(pl, l.getWalls()); 
		}
		if(goobs.size()!=0||BossVisible())l.getDoor().setOpen(false);
		if(showKey) k.setS(true);
		else k.setS(false);
		if(goobs.size()==0&&(!BossVisible())&&(!k.getS())&&(l.getLevel()!=0||l.getHasMenu())) l.getDoor().setOpen(true);
		if(l.getDoor().getOpen())
		{
			if(l.getDoor().pCollision(pl)) 
			{
				setLevel(l.getLevel()+1);
			}
		}
	}
	
	public void setLevel(int level)
	{
		l = new Level(level);
		coins.clear();
		if(l.getLevel()%5==0) spawnB(l.getLevel()/5);
		else 
		{
			int goobLevel = l.getLevel()%5;
			int goobType = l.getType();
			if(l.getLevel()%5!=0)spawn(goobLevel, goobType);
		}
		firepillars.clear();
		if(l.getLevel()>0&&l.getLevel()<6)
		{
			for(int i = 0; i < level+1; i++)
			{
				int a = ((int)(Math.random()*2))*880;
				firepillars.add(new FirePillar((int)(Math.random()*440+60+a), 480, 60, 180));
			}
		}
		if(l.getLevel()>5&&l.getLevel()<11) wat.setVisible(true);
		else wat.setVisible(false);
		stalactites.clear();
		if(l.getLevel()>10&&l.getLevel()<16) summonStalactites(level);
		clouds.clear();
		if(l.getLevel()>15&&l.getLevel()<21) summonClouds(level);
	}
	  
	public void summonClouds(int level) 
	{
		for(int i = 0; i < level-12; i++)
		{
			int x;
			boolean s = (int)(Math.random()*2)==1;
			if(s) x = 1;
			else x = -1;
			clouds.add(new Cloud(-240, (int)(Math.random()*300+280), 720, 180, (int)(Math.random()*4+1)*x));
		}
	}
	public void spawnB(int num)
	{
		if(num==1&&!defeatFire) ar.setVisible(true);
		if(num==2&&!defeatWater) aq.setS(true);
		if(num==3&&!defeatEarth) pe.setVisible(true);
		if(num==4&&!defeatAir) v.setVisible(true);
		if(num==5&&!defeatFinal) ge.setVisible(true);
	}
	public boolean BossVisible()
	{
		return ar.getVisible()||aq.getS()||pe.getVisible()||v.getVisible()||ge.getVisible();
	}
	public void spawn(int num, int type)
	{
		for(int i = 0; i < num; i++) 
		{
			int a = (int)(Math.random()*2)*880;
			if(type<5) goobs.add(new Goober(type, type*0.2+0.8, (int) (Math.random()*440+60+a), 600));
			else  goobs.add(new Goober((int)(Math.random()*4+1), 1.8, (int) (Math.random()*440+60+a), 600));
		}
	}
	
	public void summonStalactites(int level)
	{
		for(int i = 0; i < (level-8)/3; i++)
		{
			stalactites.add(new Stalactite((int)(Math.random()*1330+60), (int)(Math.random()*50), 30, 90));
		}
	}
	
	private void plDies() 
	{
		viewDS =true;
		ds.reShuffle(l);
		goobs.clear();
		pl.setCoins(0);
		coins.clear();
		if(l.getLevel()==5) ar.setHp(b.getMaxHp());
		if(l.getLevel()==10) aq.setHp(b.getMaxHp()); 
		if(l.getLevel()==15) pe.setHp(b.getMaxHp()); 
		if(l.getLevel()==20) v.setHp(b.getMaxHp());
		if(l.getLevel()==25) ge.setHp(b.getMaxHp());
		setLevel(5*(l.getLevel()/5));
		if(l.getLevel()==0) l.endTutorial();
		pl.setHp(10+pl.getHpU()*5);
		pl.setX(60);
		pl.setY(60);
		respawnCounter = 600;
	}
}