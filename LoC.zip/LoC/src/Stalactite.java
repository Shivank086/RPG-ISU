import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class Stalactite 
{
	int x, y, w, l, ya, dmg;
	private BufferedImage stl = null;
	public Stalactite(int x, int y, int w, int l)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l;
		this.ya = 1;
		this.dmg = 10;
		try
		{
			stl = ImageIO.read(new File("Stalactite.png"));
		}catch(IOException e) {System.out.println("Failure");}
	}
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public int getYa() {return ya;}
	public int getDmg() {return dmg;}
	
	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}
	public void setW(int w) {this.w = w;}
	public void setL(int l) {this.l = l;}
	public void setYa(int ya) {this.ya = ya;}
	public void setDmg(int dmg) {this.dmg = dmg;}
	
	public void paint(Graphics g)
	{
		Graphics2D s = (Graphics2D) g;
		s.drawImage(stl, getX(), getY(), getW(), getL(), null);
	}
	
	public void move()
	{
		if(getY()>60)setYa(getYa()+1);
		setY(getY()+getYa());
	}
	
	public boolean wCollision(Wall w)
	{
		boolean collideY = (w.getY()<getY()+getL()&&getY()+getL()<w.getY()+w.getL());
		int centerX = getX()+getW()/2;
		int wCenterX = w.getX()+w.getW()/2;
		int minX = getW()/2 + w.getW()/2;
		boolean collideX = minX>=(Math.abs(wCenterX-centerX));
		return(collideX&&collideY);
	}
	
	public boolean pCollision(Player pl)
	{
		int rw = getW()/2;
		int rl = getL()/2;
		int rx = Math.abs(pl.getW())/2;
		int ry = pl.getL()/2;
		int centerX = getX()+rw;
		int centerY = getY()+rl;
		int pCenterX = pl.getX()+rx;
		int pCenterY = pl.getY()+ry;
		int minX = rx+rw;
		int minY = ry+rl;
		boolean x = minX>=Math.abs(pCenterX-centerX);
		boolean y = minY>=Math.abs(pCenterY-centerY);
		return (x&&y);
	}
}
