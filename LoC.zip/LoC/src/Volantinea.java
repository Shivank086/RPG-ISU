import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class Volantinea 
{
	private int hp;
	private int xa;
	private int ya;
	private int x;
	private int y;
	private int w;
	private int l;
	private int timer;
	private int flyTimer;
	private int dmg;
	private boolean visible;
	private boolean dive;
	private BufferedImage VolantineaFly1;
	private BufferedImage VolantineaFly2;
	private BufferedImage VolantineaDive;
	
	public int getHp() {return hp;}
	public int getXa() {return xa;}
	public int getYa() {return ya;}
	public int getTimer() {return timer;}
	public int getFlyTimer() {return flyTimer;}
	public int getDmg() {return dmg;}
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public boolean getVisible() {return visible;}
	public boolean getDive() {return dive;}


	public void setHp(int hold) {hp = hold;}
	public void setX(int hold) {x = hold;}
	public void setY(int hold) {y = hold;}
	public void setW(int hold) {w = hold;}
	public void setL(int hold) {l = hold;}
	public void setXa(int hold) {xa = hold;}
	public void setYa(int hold) {ya = hold;}
	public void setTimer(int hold) {timer = hold;}
	public void setFlyTimer(int hold) {flyTimer = hold;}
	public void setVisible(boolean hold) {visible = hold;}
	public void setDive(boolean hold) {dive = hold;}
	
	public Volantinea(int x, int y, int w, int l, int xa, int ya, int hp, int dmg, boolean visible)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l;
		this.visible = visible;
		this.xa = xa;
		this.ya = ya;
		this.hp = hp;
		this.dmg = dmg;
		timer = 500;
		flyTimer = 0;
		dive = false;
		try
		{
			VolantineaFly1 = ImageIO.read(new File("AirBoss0.png"));
		}catch(IOException e){System.out.println("failure");}
		try
		{
			VolantineaFly2 = ImageIO.read(new File("AirBoss1.png"));
		}catch(IOException e){System.out.println("failure");}
		try
		{
			VolantineaDive = ImageIO.read(new File("AirBoss2.png"));
		}catch(IOException e){System.out.println("failure");}
	}
	
	public void paint(Graphics g)
	{
		Graphics2D v = (Graphics2D) g;
		if(getDive()) v.drawImage(VolantineaDive, getX(), getY(), getW(), getL(), null);
		else if((getFlyTimer()/10)%2==0) v.drawImage(VolantineaFly1, getX(), getY(), getW(), getL(), null);
		else v.drawImage(VolantineaFly2, getX(), getY(), getW(), getL(), null);
	}
	
	public void move(Player pl)
	{
		if(!getDive()) 
		{
			setXa(pl.getXa());
			if(pl.getX()+pl.getW()/2>getX()+getW()/2 + 20) setXa(getXa()+5);
			if(pl.getX()+pl.getW()/2<getX()+getW()/2 - 20) setXa(getXa()-5);

		}
		if(getDive()) setYa(10);
		else if(getY()>60) setYa(-5);
		else 
		{
			setYa(0);
		}
		if(getX()+getXa()>60&&getX()+getXa()+getW()<1440) setX(getX()+getXa());
		if(getY()+getYa()+getL()>660&&getDive()) 
		{
			setDive(false);
			setYa(0);
		}
		setY(getYa()+getY());
		if(getTimer()<1) 
		{
			setDive(true);
			setTimer(500);
		}
		if(!getDive())
		{
			setTimer(getTimer()-1);
			setFlyTimer(getFlyTimer()+1);
			if(getFlyTimer()>999) setFlyTimer(0);
		}
	}
	
	public boolean pCollide(Player pl)
	{
		int vrx = getW()/2;
		int vry = getL()/2;
		int prx = Math.abs(pl.getW())/2;
		int pry = pl.getL()/2;
		int centerX = getX()+vrx;
		int centerY = getY()+vry;
		int pCenterX = pl.getX()+vrx;
		int pCenterY = pl.getY()+vry;
		int minX = vrx+prx;
		int minY = vry+pry;
		boolean x = minX>=Math.abs(pCenterX-centerX);
		boolean y = minY>=Math.abs(pCenterY-centerY);
		return (x&&y);
	}
}
