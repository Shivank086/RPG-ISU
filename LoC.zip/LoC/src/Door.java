import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.*;
import java.awt.image.*;
public class Door 
{
	private int x, y, w, l;
	private boolean open;
	private BufferedImage closedDoor = null;
	private BufferedImage openDoor = null;
	public Door(int x, int y, int w, int l)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l;
		open = false;
		try 
		{
			closedDoor = ImageIO.read(new File("Closed_Door.png"));
		}catch(IOException e) {}
		try 
		{
			openDoor = ImageIO.read(new File("Open_Door.png"));
		}catch(IOException e) {}
	}
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public boolean getOpen() {return open;}
	
	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}
	public void setW(int w) {this.w = w;}
	public void setL(int l) {this.l = l;}
	public void setOpen(boolean open) {this.open = open;}
	
	public void paint(Graphics g)
	{
		Graphics2D d = (Graphics2D) g;
		if(getOpen())d.drawImage(openDoor.getSubimage(37, 19, 29, 50), getX(), getY()-60, getW(), getL(), null);
		else d.drawImage(closedDoor.getSubimage(37, 19, 29, 50), getX(), getY()-60, getW(), getL(), null);
	}
	public boolean pCollision(Player pl)
	{
		return((pCollideY(pl))&&pCollideX(pl));
	}
	
	public boolean pCollideX(Player pl)
	{
		boolean fromLeft = (getX()+getW()+2>=pl.getX()&&getX()<=2+pl.getX());
		boolean fromRight = (getX()<=2+pl.getX()+Math.abs(pl.getW())&&getX()+getW()+2>=pl.getX()+Math.abs(pl.getW()));
		return((fromLeft||fromRight));
	}
	
	public boolean pCollideY(Player pl)
	{
		boolean fromUp = (getY()+getL()+2>=pl.getY()&&getY()<=2+pl.getY());
		boolean fromDown = (getY()<=2+pl.getY()+pl.getL()&&getY()+getL()+2>=pl.getY()+pl.getL());
		return (fromUp||fromDown);
	}
	
}
