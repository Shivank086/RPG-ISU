import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.image.*;
public class Fireball 
{
	private int x, y, w, l, spd, direction, dmg;
	private BufferedImage fire;
	public Fireball(int x, int y, int w, int l, int spd, int direction, int dmg)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l; 
		this.spd = spd;
		this.direction = direction;
		this.dmg = dmg;
		try
		{
			fire = ImageIO.read(new File("FireBall"+direction+".png"));
		}catch(IOException e) {}
		
	}
	
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public int getSpd() {return spd;}
	public int getDirection() {return direction;}
	public int getDmg() {return dmg;}
	
	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}
	public void setW(int w) {this.w = w;}
	public void setL(int l) {this.l = l;}
	public void setSpd(int spd) {this.spd = spd;}
	public void setDirection(int direction) {this.direction = direction;}
	public void setDmg(int dmg) {this.dmg = dmg;}
	
	public void paint(Graphics g)
	{
		Graphics2D f = (Graphics2D) g;
		f.drawImage(fire, getX(), getY(), getW(), getL(), null);
	}
	
	public void move()
	{
		if(getDirection() == 0) setY(getY()-getSpd());
		else if(getDirection() == 1) setX(getX()+getSpd());
		else if(getDirection() == 2) setY(getY()+getSpd());
		else setX(getX()-getSpd());
	}
	
	public boolean pCollision(Player p)
	{
		int wRad = getW()/2;
		int lRad = getL()/2;
		int pwRad = Math.abs(p.getW())/2;
		int plRad = p.getL()/2;
		int centerX = getX() + wRad;
		int centerY = getY() + lRad;
		int pCenterX = p.getX() + pwRad;
		int pCenterY = p.getY() + plRad;
		int dx = Math.abs(centerX-pCenterX);
		int dy = Math.abs(centerY-pCenterY);
		int minDx = wRad + pwRad;
		int minDy = lRad + plRad;
		return(dx<minDx&&dy<minDy);
	}
	
	public boolean gCollision(Goober g)
	{
		int wRad = getW()/2;
		int lRad = getL()/2;
		int gwRad = g.getDim()/2;
		int glRad = g.getDim()/2;
		int centerX = getX() + wRad;
		int centerY = getY() + lRad;
		int gCenterX = g.getX() + gwRad;
		int gCenterY = g.getY() + glRad;
		int dx = Math.abs(centerX-gCenterX);
		int dy = Math.abs(centerY-gCenterY);
		int minDx = wRad + gwRad;
		int minDy = lRad + glRad;
		return(dx<minDx&&dy<minDy);
	}
	
	public boolean wCollision(Wall w)
	{
		int wRad = getW()/2;
		int lRad = getL()/2;
		int wwRad = w.getW()/2;
		int wlRad = w.getL()/2;
		int centerX = getX() + wRad;
		int centerY = getY() + lRad;
		int wCenterX = w.getX() + wwRad;
		int wCenterY = w.getY() + wlRad;
		int dx = Math.abs(centerX-wCenterX);
		int dy = Math.abs(centerY-wCenterY);
		int minDx = wRad + wwRad;
		int minDy = lRad + wlRad;
		return(dx<minDx&&dy<minDy);
	}

	public boolean geCollision(Gehenna ge)
    {
        int wRad = getW()/2;
        int lRad = getL()/2;
        int gwRad = ge.getW()/2;
        int glRad = ge.getL()/2;
        int centerX = getX() + wRad;
        int centerY = getY() + lRad;
        int gCenterX = ge.getX() + gwRad;
        int gCenterY = ge.getY() + glRad;
        int dx = Math.abs(centerX-gCenterX);
        int dy = Math.abs(centerY-gCenterY);
        int minDx = wRad + gwRad;
        int minDy = lRad + glRad;
        return(dx<minDx&&dy<minDy);
    }

	public boolean arCollision(Ardinium ar)
    {
        int wRad = getW()/2;
        int lRad = getL()/2;
        int gwRad = ar.getW()/2;
        int glRad = ar.getL()/2;
        int centerX = getX() + wRad;
        int centerY = getY() + lRad;
        int gCenterX = ar.getX() + gwRad;
        int gCenterY = ar.getY() + glRad;
        int dx = Math.abs(centerX-gCenterX);
        int dy = Math.abs(centerY-gCenterY);
        int minDx = wRad + gwRad;
        int minDy = lRad + glRad;
        return(dx<minDx&&dy<minDy);
    }

	public boolean aqCollision(Aquigo aq)
    {
        int wRad = getW()/2;
        int lRad = getL()/2;
        int gwRad = aq.getW()/2;
        int glRad = aq.getL()/2;
        int centerX = getX() + wRad;
        int centerY = getY() + lRad;
        int gCenterX = aq.getX() + gwRad;
        int gCenterY = aq.getY() + glRad;
        int dx = Math.abs(centerX-gCenterX);
        int dy = Math.abs(centerY-gCenterY);
        int minDx = wRad + gwRad;
        int minDy = lRad + glRad;
        return(dx<minDx&&dy<minDy);
    }
	
	public boolean voCollision(Volantinea vo)
    {
        int wRad = getW()/2;
        int lRad = getL()/2;
        int gwRad = vo.getW()/2;
        int glRad = vo.getL()/2;
        int centerX = getX() + wRad;
        int centerY = getY() + lRad;
        int gCenterX = vo.getX() + gwRad;
        int gCenterY = vo.getY() + glRad;
        int dx = Math.abs(centerX-gCenterX);
        int dy = Math.abs(centerY-gCenterY);
        int minDx = wRad + gwRad;
        int minDy = lRad + glRad;
        return(dx<minDx&&dy<minDy);
    }
	
	public boolean peCollision(Petrissima pe)
    {
        int wRad = getW()/2;
        int lRad = getL()/2;
        int gwRad = pe.getW()/2;
        int glRad = pe.getL()/2;
        int centerX = getX() + wRad;
        int centerY = getY() + lRad;
        int gCenterX = pe.getX() + gwRad;
        int gCenterY = pe.getY() + glRad;
        int dx = Math.abs(centerX-gCenterX);
        int dy = Math.abs(centerY-gCenterY);
        int minDx = wRad + gwRad;
        int minDy = lRad + glRad;
        return(dx<minDx&&dy<minDy);
    }
}
