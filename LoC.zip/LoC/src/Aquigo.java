import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class Aquigo 
{
	private int hp;
	private int x;
	private int y;
	private int w;
	private int l;
	private BufferedImage Aquigo0, Star, WaterShield;
	private boolean s, sh;
	
	public int getHp() {return hp;}
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public boolean getS() {return s;}
	public boolean getSh() {return sh;}

	public void setHp(int hold) {hp = hold;}
	public void setX(int hold) {x = hold;}
	public void setY(int hold) {y = hold;}
	public void setW(int hold) {w = hold;}
	public void setL(int hold) {l = hold;}
	public void setS(boolean hold) {s = hold;}
	public void setSh(boolean hold) {sh = hold;}
	
	public Aquigo(int x, int y, int w, int l, int hp, boolean s, boolean sh)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l;
		this.hp = hp;
		this.s = s;
		this.sh = sh;
		try
		{
			Aquigo0 = ImageIO.read(new File("WaterBoss0.png"));
		}catch(IOException e) {}
		try
		{
			Star = ImageIO.read(new File("Star.png"));
		}catch(IOException e) {}
		try
		{
			WaterShield = ImageIO.read(new File("WaterShield.png"));
		}catch(IOException e) {}
	}
	
	public void paint(Graphics g)
	{
		Graphics2D a = (Graphics2D) g;
		a.drawImage(Aquigo0, getX(), getY(), getW(), getL(), null);
		if(getSh())
		{
			a.drawImage(WaterShield, getX()+20, getY()+20, getW()-40, getL()-40, null);
		}
		else
		{
			a.drawImage(Star, getX()-10, getY(), 20, 20, null);
			a.drawImage(Star, getX()-10+getW()/4, getY()-10, 20, 20, null);
			a.drawImage(Star, getX()-10+getW()/2, getY()-15, 20, 20, null);
			a.drawImage(Star, getX()-10+getW()*3/4, getY()-10, 20, 20, null);
			a.drawImage(Star, getX()-10+getW(), getY(), 20, 20, null);
			a.drawImage(Star, getX()-10+getW()/4, getY()+10, 20, 20, null);
			a.drawImage(Star, getX()-10+getW()/2, getY()+15, 20, 20, null);
			a.drawImage(Star, getX()-10+getW()*3/4, getY()+10, 20, 20, null);
		}
	}
}
