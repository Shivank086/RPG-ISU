import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class Rock 
{
	int x, y, d, xa, dmg;
	public Rock(int x, int y, int d, int xa)
	{
		this.x = x;
		this.y = y;
		this.d = d;
		this.xa = xa;
		this.dmg = d/4;
	}
	public int getX() {return x;}
	public int getY() {return y;}
	public int getD() {return d;}
	public int getXa() {return xa;}
	public int getDmg() {return dmg;}
	
	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}
	public void setD(int d) {this.d = d;}
	public void setXa(int xa) {this.xa = xa;}
	public void setDmg(int dmg) {this.dmg = dmg;}
	
	public void paint(Graphics g)
	{
		Graphics2D r = (Graphics2D) g;
		r.setColor(Color.GRAY);
		r.fillOval(getX(), getY(), getD(), getD());
		r.setColor(Color.BLACK);
		r.fillOval(getX()+getD()/5, getY()+getD()/5, getD()/3, getD()/3);
		r.fillOval(getX()+getD()/8, getY()+getD()*3/5, getD()/8, getD()/8);
		r.fillOval(getX()+getD()/2, getY()+getD()/2, getD()*3/10, getD()*3/10);
		r.fillOval(getX()+getD()*3/5, getY()+getD()/5, getD()/6, getD()/6);
		r.drawOval(getX(), getY(), getD(), getD());
	}
	
	public void move()
	{
		setX(getX()+getXa());
	}
	
	public boolean bCollision()
	{
		return(getX()<=60||getX()+getD()>=1440);
	}
	
	public boolean plCollision(Player pl)
	{
		int r = getD()/2;
		int rx = Math.abs(pl.getW())/2;
		int ry = pl.getL()/2;
		int centerX = getX()+r;
		int centerY = getY()+r;
		int pCenterX = pl.getX()+rx;
		int pCenterY = pl.getY()+ry;
		int minX = rx+r;
		int minY = ry+r;
		boolean x = minX>=Math.abs(pCenterX-centerX);
		boolean y = minY>=Math.abs(pCenterY-centerY);
		return (x&&y);
	}
	
	public boolean peCollision(Petrissima pe)
	{
		int r = getD()/2;
		int rx = pe.getW()/2;
		int ry = pe.getL()/2;
		int centerX = getX()+r;
		int centerY = getY()+r;
		int pCenterX = pe.getX()+rx;
		int pCenterY = pe.getY()+ry;
		int minX = rx+r;
		int minY = ry+r;
		boolean x = minX>=Math.abs(pCenterX-centerX);
		boolean y = minY>=Math.abs(pCenterY-centerY);
		return (x&&y);
	}
}
