import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.image.*;

public class FirePillar 
{
	private int x, y, w, l, type, timer;
	private BufferedImage FP0 = null, FP1 = null, FP2 = null, FP3 = null, FP4 = null;
	public FirePillar(int x, int y, int w, int l)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.l = l;
		type = 0;
		timer = 100;
		try
		{
			FP0 = ImageIO.read(new File("FirePillar0.png"));
		}catch(IOException e) {System.out.println("Failure");}
		try
		{
			FP1 = ImageIO.read(new File("FirePillar1.png"));
		}catch(IOException e) {System.out.println("Failure");}
		try
		{
			FP2 = ImageIO.read(new File("FirePillar2.png"));
		}catch(IOException e) {System.out.println("Failure");}
		try
		{
			FP3 = ImageIO.read(new File("FirePillar3.png"));
		}catch(IOException e) {System.out.println("Failure");}
		try
		{
			FP4 = ImageIO.read(new File("FirePillar4.png"));
		}catch(IOException e) {System.out.println("Failure");}
	}
	
	public int getX() {return x;}
	public int getY() {return y;}
	public int getW() {return w;}
	public int getL() {return l;}
	public int getType() {return type;}
	public int getTimer() {return timer;}
	
	public void setX(int h) {x = h;}
	public void setY(int h) {y = h;}
	public void setW(int h) {w = h;}
	public void setL(int h) {l = h;}
	public void setType(int h) {type = h;}
	public void setTimer(int h) {timer = h;}
	
	public void move()
	{
		if(getTimer()<=0)
			{
			if(getType()==4) setType(0);
			else setType(getType()+1);
			setTimer(100);
		}
		else 
		{
			setTimer(getTimer()-1);
		}
	}
	
	public void paint(Graphics g)
	{
		Graphics2D f = (Graphics2D) g;
		if(getType()==0) f.drawImage(FP0, getX(), getY(), getW(), getL(), null);
		else if(getType()==1) f.drawImage(FP1, getX(), getY(), getW(), getL(), null);
		else if(getType()==2) f.drawImage(FP2, getX(), getY(), getW(), getL(), null);
		else if(getType()==3) f.drawImage(FP3, getX(), getY(), getW(), getL(), null);
		else f.drawImage(FP4, getX(), getY(), getW(), getL(), null);
	}
	
	public boolean pCollision(Player pl)
	{
		if(getType()==4)
		{
			int frx = getW()/2;
			int fry = getL()/2;
			int prx = Math.abs(pl.getW()/2);
			int pry = pl.getL()/2;
			int centerX = getX()+frx;
			int centerY = getY()+fry;
			int pCenterX = pl.getX()+prx;
			int pCenterY = pl.getY()+pry;
			int minX = frx+prx;
			int minY = fry+pry;
			boolean x = minX>=Math.abs(pCenterX-centerX);
			boolean y = minY>=Math.abs(pCenterY-centerY);
			return (x&&y);
		}
		return false;
	}
}
